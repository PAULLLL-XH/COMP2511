You can view the assignment specification here:
https://unswcse.atlassian.net/wiki/spaces/cs2511/pages/48332801/Assignment+III+Tributary