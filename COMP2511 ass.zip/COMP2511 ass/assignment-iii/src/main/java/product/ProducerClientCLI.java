package product;

//import tributary.TributaryCLI;
import cli.ClientCLI;
import tributary.TributaryServer;
import tributary.message.ErrorMessage;
import tributary.message.Message;
//import util.FileLoader;
import util.ClientSend;
import util.ClientUpdate;

import java.io.*;
//import java.net.ServerSocket;

//import java.nio.charset.Charset;
//import java.nio.charset.StandardCharsets;

public class ProducerClientCLI extends ClientCLI {
    private static final TributaryProducer tributaryProducer = TributaryProducer.getInstance();
    private TributaryServer tributaryServer = TributaryServer.getInstance();

    private ClientSend clientSend;
    public static void main(String[] args) throws IOException {
        new ProducerClientCLI(args).startInterface();
    }
    public ProducerClientCLI(String[] args) {
        System.out.println("Welcome to the ProducerCLI!");
        // parse args, load resources, etc
    }

    public ProducerClientCLI() {
        System.out.println("Welcome to the ProducerCLI!");
        // parse args, load resources, etc
    }
    public void startInterface() throws IOException {
        BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
        String inputLine;
        Message message;
        do {
            System.out.println("cmd：（-1 is the exit）");
            inputLine = consoleReader.readLine();
            ClientUpdate clientUpdate = new ClientUpdate(this);
            clientUpdate.start();
            try {
                clientUpdate.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
//            updateTributaryServer();
            updateProducerServer(tributaryServer);

//            inputLine = "create producer pr001 Integer Random";
            message = func(inputLine);
//            seadTributaryServer();
            new ClientSend(this, tributaryServer).start();
        } while (!(message instanceof ErrorMessage && ((ErrorMessage) message).getInfo().equals("Exit the program")));
    }

    public void updateProducerServer(TributaryServer tributaryServer) {
        tributaryProducer.updateTributaryServer(tributaryServer);
    }

    public TributaryServer getTributaryServer() {
        return tributaryServer;
    }

    public Message func(String inputLine) {
        if (inputLine.equals("-1")) {
            return new ErrorMessage("Exit the program");
        }
        String[] strings = inputLine.split(" ");
        if (strings.length < 3) {
            // todo
            return new ErrorMessage("Parameter error");
        }
        Message message = new Message();
        switch (strings[0]) {
            case "create":// create producer <
                if (strings.length == 5 && strings[1].equals("producer")) {
                    message = tributaryProducer.creatrProducer(strings[2], strings[3], strings[4]);
                } else if (strings.length == 4 && strings[1].equals("consumer")) {
                }
                break;
            case "produce":
                if (strings[1].equals("event")) {
                    if (strings.length < 5 || strings.length > 6) {
                        message = new ErrorMessage("Parameter error");
                        break;
                    }

                    if (strings.length == 5) {
                        message = tributaryProducer.produceEvent(strings[2], strings[3], strings[4], "-1");
                    } else {
                        message = tributaryProducer.produceEvent(strings[2], strings[3], strings[4], strings[5]);
                    }
                }
                break;
            case "parallel":
                if (strings.length == 3 && strings[1].equals("produce")) {
                    message = tributaryProducer.parallelProduce(strings[2]);
                }
                break;
            case "delete":
                if (strings.length == 3 && strings[1].equals("consumer")) {
                }
//                todo
                break;
        }
        System.out.println(message);
        return message;
    }


    @Override
    public void updateSever(TributaryServer tributaryServer) {
        this.tributaryServer = tributaryServer;
    }
}
