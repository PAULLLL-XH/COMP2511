package product;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
//import javassist.bytecode.analysis.Executor;
import product.allocationStrategy.AllocationStrateg;
import tributary.TributaryServer;
import tributary.event.Event;
import tributary.partition.Partition;

import java.io.Serializable;
//import java.net.Socket;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.*;

public class Producer implements Serializable {
    private AllocationStrateg allocationStrateg; //
    private String producerId;
    private String type;
    private Partition partition; //
    private Event event;
    private String eventValue;
    private transient ExecutorService executorService;
    private static TributaryProducer tributaryProducer = TributaryProducer.getInstance();

    private final static TributaryServer TRIBUTARY_SERVER = TributaryServer.getInstance();
    public Producer(String producerId, String type, String allocation) {
        this.producerId = producerId;
        this.type = type;
        this.allocationStrateg = AllocationStrateg.get(allocation);
        this.executorService = Executors.newSingleThreadExecutor();
    }

    public AllocationStrateg getAllocationStrateg() {
        return allocationStrateg;
    }

    public void setPartition(Partition partition) {
        this.partition = partition;
    }

    public String getType() {
        return type;
    }

//    public String getProducerId() {
//        return producerId;
//    }

    public void setEventValue(String eventValue) {
        this.eventValue = eventValue;
    }

    public Event active() {
        Future<Event> submit = executorService.submit(new Callable<Event>() {
            @Override
            public Event call() throws Exception {
                //       todo event convert
                event = createEvent(type, eventValue);
                partition.addEvent(event);
                return event;
            }
        });
        try {
            event = submit.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return event;

    }
/*
// JSON.parseObject(String text, Class<T> clazz)
List<T> res = new ArrayList<>(hits.length);
for (SearchHit hit : hits) {
    res.add(JSON.parseObject(hit.getSourceAsString(), c));
}

 */
    private Event createEvent(String type, String eventValue) {
        event = new Event();
        JSONObject config = JSONObject.parseObject(eventValue);
        JSONObject header = (JSONObject) config.get("header");
        event.setID((String) header.get("ID"));
        event.setDate(getDate(header.get("Datetime").toString()));
        event.setSource((String) header.get("Source"));
        String value = form(config.get("Value").toString());
//        System.out.println("eventValue = " + eventValue);
//        System.out.println("value = " + value);
        event.setValue(JSON.parseObject(value, getClazz(type)));
        return event;

    }

    private String form(String value) {
//        return "{ \"Value\": \""+value+"\"}";
        if (value.charAt(0) == '{') {
            return value;
        }
        return "\"" + value + "\"";

    }

    private Date getDate(String datetime) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        try {
            date = simpleDateFormat.parse(datetime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    public boolean isNum(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public Class<?> getClazz(String clazzName) {
        try {
            return Class.forName(clazzName);
        } catch (ClassNotFoundException e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return "Producer{" +
                "allocationStrateg=" + allocationStrateg +
                ", producerId='" + producerId + '\'' +
                ", type='" + type + '\'' +
                ", partition=" + partition +
                ", event=" + event +
                ", eventValue='" + eventValue + '\'' +
                ", executorService=" + executorService +
                '}';
    }
}
