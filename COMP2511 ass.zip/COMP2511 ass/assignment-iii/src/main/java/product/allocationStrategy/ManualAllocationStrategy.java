package product.allocationStrategy;


public class ManualAllocationStrategy extends AllocationStrateg {
}
