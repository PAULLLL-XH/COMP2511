package product.allocationStrategy;

public class RandomAllocationStrategy extends AllocationStrateg {

}
