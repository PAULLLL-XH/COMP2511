package product.allocationStrategy;

import product.Producer;

import java.io.Serializable;

/* strategy */
public class AllocationStrateg implements Serializable {
    public static AllocationStrateg get(String allocation) {
        switch (allocation){
            case "Random":
                return new RandomAllocationStrategy();
            case "Manual":
                return new ManualAllocationStrategy();
            default: // todo
                return new RandomAllocationStrategy();
        }
    }

    public String active(Producer producer) {
        return "";
    }
}
