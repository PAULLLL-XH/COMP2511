package product;

//import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
//import com.alibaba.fastjson.JSONObject;
import product.allocationStrategy.ManualAllocationStrategy;
import tributary.TributaryServer;
import tributary.event.Event;
import tributary.message.*;
import tributary.partition.Partition;
import tributary.topic.Topic;
//import util.FileLoader;
import util.JSONUtil;
import util.ParallelProducer;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class TributaryProducer {
    private static TributaryProducer tributaryProducer = new TributaryProducer();
    private TributaryServer tributaryServer = TributaryServer.getInstance();

    private HashMap<String, Producer> producers = new HashMap<>();

    private TributaryProducer() {
    }
    public static TributaryProducer getInstance() {
        return tributaryProducer;
    }

    /**
     * create producer <producersId> <type> <allocation>
     */
    public Message creatrProducer(String producerId, String type, String allocation) {

//        producers.put(producersId, new Producer());
        return addProducer(producerId, type, allocation) ? new CreateProducerMessage(producerId, type, allocation, true):
                new CreateProducerMessage(producerId, type, allocation, false);
    }

    private boolean addProducer(String producerId, String type, String allocation) {
        if (producers.containsKey(producerId)) {
            return false;
        }
        // todo type and allocation
        producers.put(producerId, new Producer(producerId, type, allocation));
        return true;
    }

    /**
     * produce event <producerId> <topic> <event> <partition>
     */
    public Message produceEvent(String producerId, String topicId, String path, String partitionId) {
        if (!producers.containsKey(producerId)) {
            return new ErrorMessage("producerId = " + partitionId + " producer is not exist");
        }
        if (!tributaryServer.getTopics().containsKey(topicId)) {
            return new ErrorMessage("topicId = " + topicId + " topic is not exist");
        }
        String eventValue = JSONUtil.getJsonValue(path);
        if (eventValue.equals("")) {
            return new ErrorMessage("event is empty");
        }
        Topic topic = tributaryServer.getTopics().get(topicId);
        Partition partition = null;
        Producer producer = producers.get(producerId);
        if (!topic.getType().equals(producer.getType())) {
            return new ErrorMessage("type error");
        }
        if (producer.getAllocationStrateg() instanceof ManualAllocationStrategy
                && topic.getPartitions().containsKey(partitionId)) {
            partition = topic.getPartition(partitionId);
        } else {
            partition = topic.getRandPartition();
//            if (partition == null) {
//                return new ErrorMessage("partitionId = " + partitionId + " partition is not exit");
//            }
        }
        partition.setProducer(producer);
        producer.setPartition(partition);
        producer.setEventValue(eventValue);
        Event event = producer.active();

//        System.out.println(event.toString());
        return new ProduceEventMessage(event, partition.getPartitonId());
    }




    /**
     * todo
     * parallel produce (<producer>, <topic>, <event>), ...
     *
     */
    public Message parallelProduce(String path) {
        String value = JSONUtil.getJsonValue(path);
        LinkedList<Message> messages = new LinkedList<>();
        List<ParallelProducer> parallelProducers = JSONArray.parseArray(value, ParallelProducer.class);
        for (ParallelProducer p : parallelProducers) {
            messages.add(produceEvent(p.getProducerId(), p.getTopicId(), p.getEventPath(), "-1"));
        }
        return new ParallelProduceMessage(messages);
    }


    public void updateTributaryServer(TributaryServer tributaryServer) {
        this.tributaryServer = tributaryServer;
    }
}
