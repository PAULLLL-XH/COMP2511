package util;

import tributary.Tributary;
import tributary.TributaryServer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class SeverConnect extends Thread{
    private int port = 1999;
    private TributaryServer tributaryServer;
    public SeverConnect(TributaryServer tributaryServer, int... ints){
        if (ints != null && ints.length != 0){
            this.port = ints[0];
        }
        this.tributaryServer = tributaryServer;
    }
    @Override
    public void run() {
        ServerSocket serverSocket = null;
        try {
            serverSocket = new ServerSocket(port);
        } catch (IOException e) {
            e.printStackTrace();
        }
        while (true) {
            try {
                assert serverSocket != null;
                Socket client = serverSocket.accept();
                new Myserver(client, tributaryServer).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void setTributaryServer(TributaryServer tributaryServer) {
        this.tributaryServer = tributaryServer;
    }
}
