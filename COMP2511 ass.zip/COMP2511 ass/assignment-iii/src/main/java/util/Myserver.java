package util;

import tributary.TributaryCLI;
import tributary.TributaryServer;

import java.io.*;
import java.net.Socket;

public class Myserver extends Thread{
    private Socket client;
    private TributaryServer tributaryServer;
    public Myserver(Socket client, TributaryServer tributaryServer) {
        this.client = client;
        this.tributaryServer = tributaryServer;
    }

    @Override
    public void run() {
        try {
            ObjectInputStream ois = new ObjectInputStream(
                    new BufferedInputStream(client.getInputStream()));
            Object obj = null;
            try {
                obj = ois.readObject();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            assert obj != null;

//            InputStream inputStream = client.getInputStream();
//            byte[] bytes = new byte[1024];
//            int read = inputStream.read(bytes);
            if (obj instanceof Requst){
                System.out.println("client：" + ((Requst) obj).getRequst());
                ObjectOutputStream oos = new ObjectOutputStream(client.getOutputStream());
                System.out.println("send to client: "+tributaryServer.getTopics().toString());
                oos.writeObject(tributaryServer);
//            System.out.println("xx");
                oos.flush();
                oos.close();
                ois.close();
                client.close();
            }else if (obj instanceof TributaryServer){
                ois.close();
                System.out.println("sever update TributaryServer");
                this.tributaryServer = (TributaryServer) obj;
                TributaryCLI.updateTributaryServer(tributaryServer);
//                System.out.println(this.tributaryServer.getTopics());
                client.close();
            }
//            ois.close();

        }catch (IOException e){
            e.printStackTrace();
        }
    }
}