package util;

import cli.ClientCLI;
import tributary.TributaryServer;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientUpdate extends Thread {
    int port = 1999;
    ClientCLI clientCli;
    public ClientUpdate(ClientCLI clientCli, int... ints ){
        if (ints != null && ints.length != 0){
            this.port = ints[0];
        }
        this.clientCli = clientCli;
    }
//    public ClientUpdate(TributaryServer tributaryServer){
//        this.tributaryServer = tributaryServer;
//    }



    @Override
    public void run() {
        Socket socket = null;
        try {
            socket = new Socket("127.0.0.1", port);
            System.out.println("connect success! update");
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            oos.writeObject(new Requst());
//            System.out.println("xx");
            oos.flush();

//            OutputStream outputStream = socket.getOutputStream();
//            outputStream.write("Tributary".getBytes(StandardCharsets.UTF_8));

            byte[] bytes = new byte[1024];
            ObjectInputStream ois = new ObjectInputStream(
                    new BufferedInputStream(socket.getInputStream()));

            Object obj = ois.readObject();

            if (obj != null) {
                TributaryServer tributaryServer = (TributaryServer) obj;
                System.out.println("update"+tributaryServer.getTopics().toString());
                clientCli.updateSever(tributaryServer);
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
