package util;

import java.io.Serializable;

public class Requst implements Serializable {
    String requst = "need Tributary";

    public String getRequst() {
        return requst;
    }

    @Override
    public String toString() {
        return "Requst{" +
                "requst='" + requst + '\'' +
                '}';
    }
}
