package util;

public class ParallelConsumer {
    String consumerId;
    String partitionId;
    public ParallelConsumer(String consumerId, String partitionId){
        this.consumerId = consumerId;
        this.partitionId = partitionId;
    }

    public String getPartitionId() {
        return partitionId;
    }

    public String getConsumerId() {
        return consumerId;
    }

    @Override
    public String toString() {
        return "ParallelConsumer{" +
                "consumerId='" + consumerId + '\'' +
                ", partitionId='" + partitionId + '\'' +
                '}';
    }

}
