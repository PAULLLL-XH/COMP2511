package util;

import cli.ClientCLI;
import tributary.TributaryServer;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientSend extends Thread {
    int port = 1999;
    TributaryServer tributaryServer;
    public ClientSend(ClientCLI clientCLI, TributaryServer tributaryServer, int... ints){
        if (ints != null && ints.length != 0){
            this.port = ints[0];
        }
        this.tributaryServer = tributaryServer;
    }
//    public ClientSend(TributaryServer tributaryServer){
//        this.tributaryServer = tributaryServer;
//    }

    @Override
    public void run() {
        Socket socket = null;
        try {
            socket = new Socket("127.0.0.1", port);
            System.out.println("connect success! send");
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            System.out.println("send:"+tributaryServer.getTopics().toString());
            oos.writeObject(tributaryServer);
//            System.out.println("xx");
            oos.flush();
            oos.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
