package util;

public class JSONUtil {
    public static String getJsonValue(String path){
        String s = "";
        try {
            s = FileLoader.loadResourceFile(path);
        }catch (Exception e){
            e.printStackTrace();
        }
        return s;
    }
}
