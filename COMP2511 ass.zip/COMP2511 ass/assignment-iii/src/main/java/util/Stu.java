package util;

public class Stu {
    String name;
    int age;
    public Stu(String name,int age){
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Stu{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
