package util;

public class ParallelProducer {
    String  producerId;
    String topicId;
    String eventPath;
    public ParallelProducer(String producerId, String topicId,String eventPath){
        this.producerId = producerId;
        this.topicId = topicId;
        this.eventPath = eventPath;
    }

    public String getProducerId() {
        return producerId;
    }

    public String getTopicId() {
        return topicId;
    }

    public String getEventPath() {
        return eventPath;
    }

    @Override
    public String toString() {
        return "ParallelProducer{" +
                "producerId='" + producerId + '\'' +
                ", topicId='" + topicId + '\'' +
                ", eventPath='" + eventPath + '\'' +
                '}';
    }
}
