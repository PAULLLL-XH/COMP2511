package util;

import org.reflections.Reflections;
import org.reflections.scanners.Scanners;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public final class FileLoader {
    /**
     * Loads a resource file given a certain path that is relative to resources/
     * for example `/dungeons/maze.json`. Will add a `/` prefix to path if it's not
     * specified.
     *
     * @precondiction path exists as a file
     * @param path Relative to resources/ will add an implicit `/` prefix if not
     *             given.
     * @return The textual content of the given file.
     * @throws IOException If some other IO exception.
     */
    public static String loadResourceFile(String path) throws IOException ,NullPointerException{
//        if (!path.startsWith("/"))
//            path = "/" + path;
        System.out.println(path);
        InputStream resourceAsStream = FileLoader.class.getResourceAsStream(path);
//        String file = Objects.requireNonNull(Thread.currentThread().getContextClassLoader().getResource(path)).getFile();
//        InputStream resourceAsStream = new FileInputStream(file);
        byte[] bytes = resourceAsStream.readAllBytes();
        return new String(bytes);
    }
}
