package consumer;

//import tributary.TributaryCLI;
import cli.ClientCLI;
import tributary.TributaryServer;
import tributary.message.ErrorMessage;
import tributary.message.Message;
import util.ClientUpdate;

import java.io.*;
//import java.nio.charset.StandardCharsets;

public class ConsumerClientCLI extends ClientCLI {
    private static final TributaryConsumer tributaryConsumer = TributaryConsumer.getInstance();
    private TributaryServer tributaryServer = TributaryServer.getInstance();

    public ConsumerClientCLI(String[] args) {
        System.out.println("Welcome to the ConsumerCLI!");
        // parse args, load resources, etc
    }
    public ConsumerClientCLI() {

    }

    public TributaryServer getTributaryServer() {
        return tributaryServer;
    }

    public static void main(String[] args) throws IOException {
        new ConsumerClientCLI(args).startInterface();
    }
    public void startInterface() throws IOException {
        BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
        String inputLine;
        Message message;
        do {
            System.out.println("cmd：（-1 is the exit）");
            inputLine = consoleReader.readLine();
            ClientUpdate clientUpdate = new ClientUpdate(this);
            clientUpdate.start();
            try {
                clientUpdate.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
//            updateTributaryServer();
            updateConsumerSever(tributaryServer);
            message = func(inputLine);
//            new ClientSend(new ConsumerCLI(), tributaryServer).start();
//            seadTributaryServer();

        } while (!(message instanceof ErrorMessage && ((ErrorMessage) message).getInfo().equals("Exit the program")));
    }

    public void updateConsumerSever(TributaryServer tributaryServer) {
        tributaryConsumer.updateTributaryServer(tributaryServer);
    }

    public Message func(String inputLine) {
        if (inputLine.equals("-1")) {
            return new ErrorMessage("Exit the program");
        }
        String[] strings = inputLine.split(" ");
        if (strings.length < 3) {
            // todo
            return new ErrorMessage("Parameter error");
        }
        Message message = new Message();
        switch (strings[0]) {
            case "create":
                if (strings.length == 6 && strings[1].equals("consumer")
                        && strings[2].equals("group")) {
                    System.out.println("inputLine = " + inputLine);;
                    message = tributaryConsumer.createConsumerGroup(strings[3], strings[4], strings[5]);
                } else if (strings.length == 4 && strings[1].equals("consumer")) {
                    message = tributaryConsumer.createConsumer(strings[2], strings[3]);
                }
                break;
            case "delete":
                if (strings.length == 3 && strings[1].equals("consumer")){
                    message = tributaryConsumer.deleteConsumer(strings[2]);
                }
//                todo
                break;//consume event c002 p001
            case "consume":
                if (strings.length == 4 && strings[1].equals("event")) {
                    message = tributaryConsumer.consumeEvent(strings[2], strings[3]);
                } else if (strings.length == 5 && strings[1].equals("events")) {
                    message = tributaryConsumer.consumerEvents(strings[2], strings[3], strings[4]);
                }
            case "parallel":
                if (strings.length == 3 && strings[1].equals("consumer")) {
                    message = tributaryConsumer.parallelConsume(strings[2]);
                }
                break;
            case "set"://case "set consumer group rebalancing g001 RoundRobin"
                if (strings.length == 6 && strings[1].equals("consumer")
                && strings[2].equals("group") && strings[3].equals("rebalancing")) {
                    message = tributaryConsumer.setConsumerGroupRebalancing(strings[4], strings[5]);
                }
                break;
            case "playback":
                // playback c002 p001 0 3
                if (strings.length == 5) {
                    message = tributaryConsumer.playback(strings[1], strings[2], strings[3], strings[4]);
                }
                break;
        }
        System.out.println("message = " + message);
        return message;
    }

    @Override
    public void updateSever(TributaryServer tributaryServer) {
        this.tributaryServer = tributaryServer;
    }

//    public void updateTributaryServer(){
//        Socket socket = null;
//        Socket client = null;
//        try {
//            socket = new Socket("127.0.0.1",9999);
//            OutputStream outputStream = socket.getOutputStream();
//            outputStream.write("Tributary".getBytes(StandardCharsets.UTF_8));
//            byte[] bytes = new byte[1024];
//
//            ObjectInputStream ois = new ObjectInputStream(
//                    new BufferedInputStream(socket.getInputStream()));
//
//            Object obj = ois.readObject();
//
//            if (obj != null) {
//                tributaryServer = (TributaryServer) obj;
//                System.out.println(tributaryServer.getTopics().size());
//            }
//
//        }catch (IOException | ClassNotFoundException e){
//            e.printStackTrace();
//        }
//    }
//    private void seadTributaryServer() {
//        Socket socket = null;
//        try {
//            socket = new Socket("127.0.0.1", 9999);
//            System.out.println("connect success! send");
//            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
//            System.out.println(tributaryServer.getTopics().toString());
//            oos.writeObject(tributaryServer);
//    //            System.out.println("xx");
//            oos.flush();
//            oos.close();
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//    public void updateTributaryServer(int... ints) {
//        int port = 9999;
//        if (ints != null && ints.length != 0){
//            port = ints[0];
//        }
//        Socket socket = null;
//        try {
//            System.out.println("port = " + port);
//            socket = new Socket("127.0.0.1", port);
//            System.out.println("connect success! update");
//            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
//            oos.writeObject(new Requst());
//    //            System.out.println("xx");
//            oos.flush();
//
//    //            OutputStream outputStream = socket.getOutputStream();
//    //            outputStream.write("Tributary".getBytes(StandardCharsets.UTF_8));
//
//            byte[] bytes = new byte[1024];
//            ObjectInputStream ois = new ObjectInputStream(
//                    new BufferedInputStream(socket.getInputStream()));
//
//            Object obj = ois.readObject();
//
//            if (obj != null) {
//                tributaryServer = (TributaryServer) obj;
//                System.out.println(tributaryServer.getTopics().size());
//            }
//
//        } catch (IOException | ClassNotFoundException e) {
//            e.printStackTrace();
//        }
//    }
}
