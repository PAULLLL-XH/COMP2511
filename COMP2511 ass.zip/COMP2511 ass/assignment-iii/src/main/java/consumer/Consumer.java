package consumer;

import tributary.event.Event;
import tributary.partition.Partition;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.*;

public class Consumer {
    private HashMap<String, Partition> partitions;
    private HashMap<String, Integer> offsetMap;
    private ExecutorService executorService;

    public Consumer() {
        offsetMap = new HashMap<>();
        partitions = new HashMap<>();
        this.executorService = Executors.newSingleThreadExecutor();

    }
    public HashMap<String, Partition> getPartitions() {
        return partitions;
    }

//    public HashMap<String, Integer> getOffsetMap() {
//        return offsetMap;
//    }
//
//    public void setOffsetMap(HashMap<String, Integer> offsetMap) {
//        this.offsetMap = offsetMap;
//    }
//    public int getOffset(String partirionId) {
//        return offsetMap.get(partirionId);
//    }
    public void setOffset(String partitionId, int offset) {
        offsetMap.put(partitionId, offset);
    }

    public void Rebalance() {
        offsetMap = new HashMap<>();
        partitions = new HashMap<>();
    }

    public void add(String partitionId, Partition partition) {
        partitions.put(partitionId, partition);
        offsetMap.put(partitionId, 0);
    }

    public Partition getPartition(String partitionId) {
        return partitions.get(partitionId);
    }

    public Event active(String partitionId, Partition partition) {
        Future<Event> submit = executorService.submit(new Callable<Event>() {

            @Override
            public Event call() throws Exception {
                LinkedList<Event> events = partition.getEvents();
                int offset = offsetMap.get(partitionId);
                System.out.println("offset = " + offset);

                System.out.println("events = " + events.size());
                if (offset >= events.size()) {
                    return null;
                }
                Event event = events.get(offset);
                offsetMap.put(partitionId, offset + 1);
                return event;
            }
        });
        Event event = null;
        try {
            event  = submit.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return event;
    }
}
