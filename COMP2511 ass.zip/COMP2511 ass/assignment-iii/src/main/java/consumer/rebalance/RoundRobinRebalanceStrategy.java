package consumer.rebalance;

import consumer.Consumer;
import tributary.partition.Partition;
import tributary.topic.Topic;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;

public class RoundRobinRebalanceStrategy extends RebalanceStrategy{
    @Override
    public void active(HashMap<String, Consumer> consumers, Topic topic) {
        // a: 1 3 5 7 b:2 4 6   a: 1 4 7 b:2 5 c:3 6
        LinkedHashMap<String, Partition> partitions = topic.getPartitions();
        LinkedList<String> partitionIds = new LinkedList<>(partitions.keySet());
        int n = partitions.size();
        int m = consumers.size();
        if (m == 0){
            return;
        }
        if (n == 0) {
            consumers.values().forEach(Consumer::Rebalance);
            return;
        }
        int a = n / m; //
        int b = n % m; //
        int cnt = 0;
        int j = 0;
        for (Consumer consumer : consumers.values()) {
            consumer.Rebalance();
            j++;
            for (int i = 0; cnt < n && i < a; i++, cnt++) {
                cnt = i * m + j;
                String id = partitionIds.get(cnt);
                consumer.add(id, partitions.get(id));
            }
            if (b-- > 0) {
                cnt = a * m + j;
                String id = partitionIds.get(cnt++);
                consumer.add(id, partitions.get(id));
            }
        }
    }
}
