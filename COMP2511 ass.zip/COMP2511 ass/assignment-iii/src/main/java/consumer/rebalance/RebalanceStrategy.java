package consumer.rebalance;

import consumer.Consumer;
import tributary.topic.Topic;

import java.util.HashMap;

public abstract class RebalanceStrategy {
    public static RebalanceStrategy get(String rebalanceType) {
        switch (rebalanceType) {
            case "Range":
                return new RangeRebalanceStrategy();
            case "RoundRobin":
                return new RoundRobinRebalanceStrategy();
            default: // todo
                return new RoundRobinRebalanceStrategy();
        }
    }
    public abstract void active(HashMap<String, Consumer> consumers, Topic topic);


}
