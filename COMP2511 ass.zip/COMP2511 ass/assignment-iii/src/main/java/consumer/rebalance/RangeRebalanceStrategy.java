package consumer.rebalance;

import consumer.Consumer;
import tributary.partition.Partition;
import tributary.topic.Topic;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;

public class RangeRebalanceStrategy extends RebalanceStrategy {
    @Override
    public void active(HashMap<String, Consumer> consumers, Topic topic) {
        // a: 1 2 3 4  b:5 6 7
        LinkedHashMap<String, Partition> partitions = topic.getPartitions();
        LinkedList<String> partitionIds = new LinkedList<>(partitions.keySet());
        int n = partitions.size();
        int m = consumers.size();
        if (m == 0) {
            return;
        }
        if (n == 0) {
            consumers.values().forEach(Consumer::Rebalance);
            return;
        }
        int a = n / m;
        int b = n % m;
        int cnt = 0;
        for (Consumer consumer : consumers.values()) {
            consumer.Rebalance();
            for (int i = 0; cnt < n && i < a; i++, cnt++) {
                String id = partitionIds.get(cnt);
                consumer.add(id, partitions.get(id));
            }
            if (b-- > 0) {
                String id = partitionIds.get(cnt++);
                consumer.add(id, partitions.get(id));
            }
        }
    }
}
