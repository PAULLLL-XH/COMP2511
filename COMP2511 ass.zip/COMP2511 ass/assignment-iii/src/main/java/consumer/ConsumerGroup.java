package consumer;

import consumer.rebalance.RebalanceStrategy;
//import tributary.message.RebalancingMessage;
import tributary.topic.Topic;

import java.util.HashMap;
import java.util.LinkedList;

public class ConsumerGroup {
    private String topicId;
    private Topic topic;
    private RebalanceStrategy rebalance;
    private HashMap<String, Consumer> consumers = new HashMap<>();;
//    public ConsumerGroup() {
//
//    }
//    public ConsumerGroup(String topicId) {
//        this.topicId = topicId;
//
//    }
    public Consumer getConsumer(String consumerId) {
        return consumers.get(consumerId);
    }

    public ConsumerGroup(Topic topic, String rebalanceType) {
        this.topic = topic;
        topicId = topic.getId();
        this.rebalance = RebalanceStrategy.get(rebalanceType);
    }

    public void setRebalance(String rebalanceName) {
        this.rebalance = RebalanceStrategy.get(rebalanceName);
        rebalance.active(consumers, topic);
    }

//    public HashMap<String, Consumer> getConsumers() {
//        return consumers;
//    }

    public boolean addConsumer(String consumerId) {
        if (consumers.containsKey(consumerId)) {
            return false;
        }
        consumers.put(consumerId, new Consumer());
        rebalance.active(consumers, topic); //
        return true;
    }

    public LinkedList<String> deleteGroup(String consumerId) {
        if (!consumers.containsKey(consumerId)) {
            return null;
        }
       LinkedList<String> partitionIds =
               new LinkedList<>(consumers.get(consumerId).getPartitions().keySet());
       consumers.remove(consumerId);
       rebalance.active(consumers, topic);
       return partitionIds;
    }
}
