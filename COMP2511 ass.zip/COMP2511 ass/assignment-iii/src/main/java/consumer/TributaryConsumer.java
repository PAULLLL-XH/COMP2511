package consumer;

import com.alibaba.fastjson.JSONArray;
//import consumer.rebalance.RebalanceStrategy;
import tributary.TributaryServer;
import tributary.event.Event;
import tributary.message.*;
import tributary.partition.Partition;
import tributary.topic.Topic;
import util.JSONUtil;
import util.ParallelConsumer;
//import util.ParallelProducer;
//
//import java.io.BufferedInputStream;
//import java.io.IOException;
//import java.io.ObjectInputStream;
//import java.io.OutputStream;
//import java.net.Socket;
//import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class TributaryConsumer {
    private HashMap<String, ConsumerGroup> consumerGroups = new HashMap<>();
    private static TributaryConsumer tributaryConsumer = new TributaryConsumer();

    private TributaryServer tributaryServer = TributaryServer.getInstance();

    public TributaryConsumer() {

    }
    public static TributaryConsumer getInstance() {
        return tributaryConsumer;
    }

    /**
     * create consumer group <groupId> <topicId> <rebalancing>
     * @param groupId
     * @param topicId
     * @param rebalance
     * @return
     */
    public Message createConsumerGroup(String groupId, String topicId, String rebalance) {
        if (consumerGroups.containsKey(groupId)) {
            return new CreateConsumerGroupMessage(groupId, false);
        }
        if (!tributaryServer.getTopics().containsKey(topicId)) {
            return new CreateConsumerGroupMessage(groupId, false);
        }
        Topic topic = tributaryServer.getTopics().get(topicId);
        consumerGroups.put(groupId, new ConsumerGroup(topic, rebalance));
        return new CreateConsumerGroupMessage(groupId, true);
    }


    /**
     * create consumer <groupId> <consumerId>
     * @param groupId
     * @param consumerId
     * @return
     */
    public Message createConsumer(String groupId, String consumerId) {
        if (!consumerGroups.containsKey(groupId)) {
            return new CreateConsumerMessage(groupId, consumerId, false);
        }
        ConsumerGroup consumerGroup = consumerGroups.get(groupId);
        return consumerGroup.addConsumer(consumerId) ?
                new CreateConsumerMessage(groupId, consumerId, true)
                : new CreateConsumerMessage(groupId, consumerId, false);
    }

    /**
     * delete consumer <consumerId>
     */
    public Message deleteConsumer(String consumerId) {
//        boolean flag = false;
        Message message = new DeleteConsumerMessage(false, null);
        for (String consumerGroupId : consumerGroups.keySet()) {
            ConsumerGroup consumerGroup = consumerGroups.get(consumerGroupId); //
            LinkedList<String> partitionIds = consumerGroup.deleteGroup(consumerId);
            if (partitionIds != null) {
                message = new DeleteConsumerMessage(true, partitionIds);
            }
        }
        return message;
    }




    /**
     * consume event <consumer> <partition>
     */
    public Message consumeEvent(String  consumerId, String partitionId) {
        Message message = new Message();
        Consumer consumer = getConsumer(consumerId);
        if (consumer == null) {
            return new ErrorMessage("consumerId = " + consumerId + " consumer is not exist");
        }
        Partition partition = consumer.getPartition(partitionId);
        if (partition == null) {
            return new ErrorMessage("partitionId = " + partitionId+ " partition is not exist");
        }
        partition.getEvents().forEach((event -> System.out.println(event.toString())));
        Event event = consumer.active(partitionId, partition);

        System.out.println("event = " + event);
        return new ConsumeEventMessage(partitionId, event);
    }

    private Consumer getConsumer(String consumerId) {
        for (ConsumerGroup group : consumerGroups.values()) {
            Consumer consumer = group.getConsumer(consumerId);
            if (consumer != null) {
                return consumer;
            }
        }
        return null;
    }

    /**
     * consume events <consumer> <partition> <number of events>
     */
    public Message consumerEvents(String  consumerId, String partitionId, String numberOfEvents) {
        LinkedList<Message> messages = new LinkedList<>();
        int n = Integer.parseInt(numberOfEvents);
        for (int i = 0; i < n; i++) {
            messages.add(consumeEvent(consumerId, partitionId));
        }
        return new ConsumerEventsMessage(messages);
    }

    /**
     * parallel consume (<consumer>, <partition>)
     */
    public Message parallelConsume(String path) {
        String value = JSONUtil.getJsonValue(path);
        LinkedList<Message> messages = new LinkedList<>();
        List<ParallelConsumer> parallelConsumers = JSONArray.parseArray(value, ParallelConsumer.class);
        for (ParallelConsumer c : parallelConsumers) {
            messages.add(consumeEvent(c.getConsumerId(), c.getPartitionId()));
        }
        return new ParallelConsumerMessage(messages);

    }

    /**
     * set consumer group rebalancing <group> <rebalancing>
     */
    public Message setConsumerGroupRebalancing(String groupId, String rebalance) {
        ConsumerGroup group = consumerGroups.get(groupId);
        if (group == null) {
            return new ErrorMessage("groupId = " + groupId + " group is not exist");
        }
        group.setRebalance(rebalance);
        return new RebalancingMessage(groupId, rebalance);
    }


    /**
     * playback <consumer> <partition> <offset> <number of events>
     */
    public Message playback(String consumerId, String partitionId, String offset, String numberOfEvents) {
        int off = Integer.parseInt(offset);
        Consumer consumer = getConsumer(consumerId);
        if (consumer == null) {
            return new ErrorMessage("consumerId = " + consumerId + " consumer is not exist");
        }
        Partition partition = consumer.getPartition(partitionId);
        if (partition == null) {
            return new ErrorMessage("partitionId = " + partitionId+ " partition is not exist");
        }
//        if (off >= partition.getEvents().size()){
//            return new ErrorMessage("offset = "+ off+" is longer than event's length");
//        }
        consumer.setOffset(partitionId, off);
        Message message = consumerEvents(consumerId, partitionId, numberOfEvents);

        return message;

    }

    public void updateTributaryServer(TributaryServer tributaryServer) {
        this.tributaryServer = tributaryServer;
    }
}
