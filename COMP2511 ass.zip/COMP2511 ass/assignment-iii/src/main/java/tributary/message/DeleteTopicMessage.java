package tributary.message;

public class DeleteTopicMessage extends Message{
    String id;
    public DeleteTopicMessage(String id){
        this.id = id;
    }
//
//    @Override
//    public String toString() {
//        return "DeleteTopicMessage{" +
//                "id='" + id + '\'' +
//                '}';
//    }
}
