package tributary.message;

public class CreateConsumerMessage extends Message{
    public boolean createdSuccess;
    private String consumerId;
    private String groupId;
    public CreateConsumerMessage(String groupId,String consumerId,boolean createdSuccess){
        this.createdSuccess = createdSuccess;
        this.consumerId = consumerId;
        this.groupId = groupId;
    }

    @Override
    public String toString() {
        return "CreateConsumerMessage{" +
                "createdSuccess=" + createdSuccess +
                ", consumerId='" + consumerId + '\'' +
                ", groupId='" + groupId + '\'' +
                '}';
    }
}
