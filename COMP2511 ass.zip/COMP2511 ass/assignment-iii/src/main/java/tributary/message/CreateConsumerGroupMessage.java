package tributary.message;

public class CreateConsumerGroupMessage extends Message{
    public boolean createdSuccess;
    private String groupId;
    public CreateConsumerGroupMessage(String groupId, boolean createdSuccess) {
        this.createdSuccess = createdSuccess;
        this.groupId = groupId;
    }


    @Override
    public String toString() {
        return "CreateConsumerGroupMessage{" +
                "createdSuccess=" + createdSuccess +
                ", groupId='" + groupId + '\'' +
                '}';
    }
}
