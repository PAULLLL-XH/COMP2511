package tributary.message;

import java.util.LinkedList;

public class ParallelConsumerMessage extends Message {
    LinkedList<Message> messages;
    public ParallelConsumerMessage(LinkedList<Message> messages){
        this.messages = messages;
    }

    @Override
    public String toString() {
        return "ParallelConsumerMessage{" +
                "messages=" + messages +
                '}';
    }

    public LinkedList<Message> getMessages() {
        return messages;
    }
}
