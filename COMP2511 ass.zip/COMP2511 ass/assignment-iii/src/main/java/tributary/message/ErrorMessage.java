package tributary.message;

public class ErrorMessage extends Message {
    String info;

    public ErrorMessage(String info){
        this.info = info;
    }

    public String getInfo() {
        return info;
    }

    @Override
    public String toString() {
        return "ErrorMessage{" +
                "info='" + info + '\'' +
                '}';
    }
}
