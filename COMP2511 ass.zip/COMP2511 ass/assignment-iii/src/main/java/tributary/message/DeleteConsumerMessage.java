package tributary.message;

import java.util.LinkedList;

public class DeleteConsumerMessage extends Message{
    public boolean deletedSuccess;
    private LinkedList<String> partitionIds;
    public DeleteConsumerMessage(boolean deletedSuccess, LinkedList<String> partitionIds){
        this.deletedSuccess = deletedSuccess;
        this.partitionIds = partitionIds;
    }

    public LinkedList<String> getPartitionIds() {
        return partitionIds;
    }


    @Override
    public String toString() {
        return "DeleteConsumerMessage{" +
                "deletedSuccess=" + deletedSuccess +
//                ", partitionIds=" + partitionIds.toString() +
                '}';
    }
}
