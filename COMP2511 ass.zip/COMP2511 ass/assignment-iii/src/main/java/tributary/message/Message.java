package tributary.message;

import java.io.Serializable;
import java.util.Objects;

public class Message implements Serializable {
    String tmp = "hello";


//    @Override
//    public String toString() {
//        return "Message{" +
//                "tmp='" + tmp + '\'' +
//                '}';
//    }

}
