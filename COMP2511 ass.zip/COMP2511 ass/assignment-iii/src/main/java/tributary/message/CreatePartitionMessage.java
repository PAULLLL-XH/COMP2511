package tributary.message;

public class CreatePartitionMessage extends Message{

    private String topicId;
    private String id;
    public CreatePartitionMessage(String topicId, String id){
        this.id = id;
        this.topicId = topicId;
    }

    public String getId() {
        return id;
    }

    public String getTopicId() {
        return topicId;
    }

    @Override
    public String toString() {
        return "CreatePartitionMessage{" +
                "topicId='" + topicId + '\'' +
                ", id='" + id + '\'' +
                '}';
    }
}
