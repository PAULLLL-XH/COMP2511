package tributary.message;

import tributary.topic.Topic;

import java.util.Objects;

public class ShowTopicMessage extends Message{
    private Topic topic;
    public ShowTopicMessage(Topic topic){
        this.topic = topic;
    }

    @Override
    public String toString() {

        return "ShowTopicMessage{" +
                "topic=" + topic.toString() +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ShowTopicMessage that = (ShowTopicMessage) o;
        return Objects.equals(topic, that.topic);
    }

    @Override
    public int hashCode() {
        return Objects.hash(topic);
    }
}
