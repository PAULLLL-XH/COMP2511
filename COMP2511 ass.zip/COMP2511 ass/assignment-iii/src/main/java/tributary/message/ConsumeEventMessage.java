package tributary.message;

import tributary.event.Event;

public class ConsumeEventMessage extends Message {
    String eventId;
    Event event;
    public ConsumeEventMessage(String eventId, Event event) {
        this.event = event;
        this.eventId = eventId;
    }

//    public Event getEvent() {
//        return event;
//    }
    @Override
    public String toString() {
        return "ConsumeEventMessage{" +
                "eventId='" + eventId + '\'' +
                ", event=" + event +
                '}';
    }
}
