package tributary.message;

public class CreateTopicMessage extends Message{
    String id;
    String type;
    public CreateTopicMessage(String id, String type){
        this.id = id;
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return "CreateTopicMessage{" +
                "id='" + id + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
