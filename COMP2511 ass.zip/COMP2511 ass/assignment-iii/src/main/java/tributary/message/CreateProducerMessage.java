package tributary.message;

public class CreateProducerMessage extends Message{
    public boolean createdSuccess;
    private String producerId;
    private String type;
    private String allocation;
    public CreateProducerMessage(String producerId, String type, String allocation,boolean createdSuccess){
        this.createdSuccess = createdSuccess;
        this.producerId = producerId;
        this.allocation = allocation;
        this.type = type;
    }

    @Override
    public String toString() {
        return "CreateProducerMessage{" +
                "createdSuccess=" + createdSuccess +
                ", producerId='" + producerId + '\'' +
                ", type='" + type + '\'' +
                ", allocation='" + allocation + '\'' +
                '}';
    }
}
