package tributary.message;

public class RebalancingMessage extends Message{
    String groupId;
    String rebalance;
    public RebalancingMessage(String groupId, String rebalance){
        this.groupId = groupId;
        this.rebalance = rebalance;
    }

    @Override
    public String toString() {
        return "RebalancingMessage{" +
                "groupId='" + groupId + '\'' +
                ", rebalance='" + rebalance + '\'' +
                '}';
    }
}
