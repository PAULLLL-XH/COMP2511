package tributary.message;

import java.util.LinkedList;

public class ParallelProduceMessage extends Message {
    LinkedList<Message> messages;
    public ParallelProduceMessage(LinkedList<Message> messages){
        this.messages = messages;
    }

    @Override
    public String toString() {
        return "ParallelProduceMessage{" +
                "messages=" + messages +
                '}';
    }

    public LinkedList<Message> getMessages() {
        return messages;
    }
}
