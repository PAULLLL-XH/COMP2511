package tributary.message;

import tributary.event.Event;

public class ProduceEventMessage extends Message{
    private String partitionId;
    private Event event;

    public ProduceEventMessage(Event event,String partitionId){
        this.partitionId = partitionId;
        this.event = event;
    }
    public String getPartitionId() {
        return partitionId;
    }

    @Override
    public String toString() {
        return "ProduceEventMessage{" +
                "partitionId='" + partitionId + '\'' +
                ", event=" + event.toString() +
                '}';
    }
}
