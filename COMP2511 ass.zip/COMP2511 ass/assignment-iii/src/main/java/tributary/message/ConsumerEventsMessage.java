package tributary.message;

import java.util.LinkedList;

public class ConsumerEventsMessage extends Message{
    LinkedList<Message> messages;
    public ConsumerEventsMessage(LinkedList<Message> messages) {
        this.messages = messages;
    }

    @Override
    public String toString() {
        return "ConsumerEventsMessage{" +
                "messages=" + messages.toString() +
                '}';
    }

    public LinkedList<Message> getMessages() {
        return messages;
    }
}
