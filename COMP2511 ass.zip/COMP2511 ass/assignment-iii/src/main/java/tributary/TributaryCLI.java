package tributary;

import tributary.message.ErrorMessage;
import tributary.message.Message;
import util.SeverConnect;

import java.io.*;

public class TributaryCLI implements Serializable {


    private static TributaryServer TRIBUTARY_SERVER = TributaryServer.getInstance();
    static SeverConnect severConnect = new SeverConnect(TRIBUTARY_SERVER);

    public TributaryCLI(String[] args) {
        System.out.println("Welcome to the TributaryCLI!");
        // parse args, load resources, etc
    }
    public TributaryCLI() {

    }
    public static void updateTributaryServer(TributaryServer tributaryServer) {
        TRIBUTARY_SERVER = tributaryServer;
        severConnect.setTributaryServer(TRIBUTARY_SERVER);
        System.out.println("received: = " + TRIBUTARY_SERVER.getTopics().toString());

    }
    public static void main(String[] args) throws ClassNotFoundException, IOException {
        new TributaryCLI(args).startInterface();
    }

    public TributaryServer getTributaryServer() {
        return TRIBUTARY_SERVER;
    }

    public void startInterface() throws IOException {
        severConnect.start();
        BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
        String inputLine;
        Message message;
        do {
            System.out.println("cmd：（-1 is the exit）");
            inputLine = consoleReader.readLine();
            message = func(inputLine);
        } while (!(message instanceof ErrorMessage && ((ErrorMessage) message).getInfo().equals("Exit the program")));
    }

    public Message func(String inputLine) {
        if (inputLine.equals("-1")) {
            return new ErrorMessage("Exit the program");
        }
        String[] strings = inputLine.split(" ");
        if (strings.length < 3) {
            // todo
            return new ErrorMessage("Parameter error");
        }
        Message message = new Message();
        switch (strings[0]) {
            case "create":
                if (strings.length == 4 && strings[1].equals("topic")) {
                    message = TRIBUTARY_SERVER.createTopic(strings[2], strings[3]);
                } else if (strings.length == 4 && strings[1].equals("partition")) {
                    message = TRIBUTARY_SERVER.createPartition(strings[2], strings[3]);
                }
                break;
            case "delete":
                if (strings.length == 3 && strings[1].equals("topic")) {
                    message = TRIBUTARY_SERVER.deleteTopic(strings[2]);
                }
                break;
            case "show":
                if (strings.length == 3 && strings[1].equals("topic")) {
                    message = TRIBUTARY_SERVER.showTopic(strings[2]);
                }
        }
        //src/resources/Event1.json
        System.out.println(message.toString());
        return message;
    }
}
