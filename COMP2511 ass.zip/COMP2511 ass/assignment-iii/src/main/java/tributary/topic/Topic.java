package tributary.topic;

import tributary.partition.Partition;

import java.io.Serializable;
import java.util.*;

public class Topic implements Serializable {
    private LinkedHashMap<String,Partition> partitions;
    private String type;
    private String id;

    public Topic(String id, String type) {
        partitions = new LinkedHashMap<>();
        this.type = type;
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public Partition getPartition(String partitionId){
        return partitions.get(partitionId);
    }

    public Partition getRandPartition(){
        int size = partitions.size();
        LinkedList<String> partitionIds = new LinkedList<>(partitions.keySet());
        Random random = new Random(System.currentTimeMillis());
        int i = random.nextInt(size);
        return partitions.get(partitionIds.get(i));
    }

    public String getId() {
        return id;
    }

    public LinkedHashMap<String, Partition> getPartitions() {
        return partitions;
    }

    public Boolean addPartition(String id) {
        if (partitions.containsKey(id)){
            return false;
        }
        partitions.put(id, new Partition(id));
        return true;
    }

    @Override
    public String toString() {
        return "Topic{" +
                "partitions=" + partitions.toString() +
                ", type='" + type + '\'' +
                ", id='" + id + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Topic)) return false;
        Topic topic = (Topic) o;
        return getPartitions().equals(topic.getPartitions()) &&
                getType().equals(topic.getType()) &&
                getId().equals(topic.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getPartitions(), getType(), getId());
    }
}
