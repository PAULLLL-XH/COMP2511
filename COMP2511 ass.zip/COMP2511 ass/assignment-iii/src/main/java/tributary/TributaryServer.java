package tributary;

//import consumer.ConsumerGroup;
import tributary.message.*;
import tributary.topic.Topic;

import java.io.Serializable;
import java.util.HashMap;
import java.util.UUID;
//import java.util.concurrent.locks.Condition;
//import java.util.concurrent.locks.ReentrantLock;

public class TributaryServer implements Serializable {
    // Feel free to delete/change this file, this is just here to give directory structure.

    private static TributaryServer tributaryServer = new TributaryServer();
    private HashMap<String, Topic> topics;


    private TributaryServer() {
        topics = new HashMap<>();
    }

    public static TributaryServer getInstance() {
        return tributaryServer;
//        return new TributaryServer();
    }

    public HashMap<String, Topic> getTopics() {
        return topics;
    }
    private Topic getTopic(String topicId) {
        return topics.get(topicId);
    }

    public Message createTopic(String id, String type) {
        // id is unique
        if (topics.keySet().contains(id)) {
            return new ErrorMessage("topicId = " + id + " topic is already exist");
        }
        Topic topic = new Topic(id, type);
        topics.put(id, topic);
        return new CreateTopicMessage(id, type);
    }

    public Message createPartition(String topicId, String id) {
        if (!topics.containsKey(topicId)) {
            return new ErrorMessage("topicId = " + topics + " is not exist");
        }
        Topic topic = topics.get(topicId);
        return topic.addPartition(id) ?
                new CreatePartitionMessage(topicId, id)
                : new ErrorMessage("topic:" + topicId + "  partition:" + id + " already exists");
    }

    public String generateEventId() {
        return UUID.randomUUID().toString();
    }

    /**
     * show topic <topic>
     */
    public Message showTopic(String topicId) {
        if (!topics.containsKey(topicId)) {
            return new ErrorMessage("topicId = " + topicId + " topic is not exist");
        }
        return new ShowTopicMessage(topics.get(topicId));
    }


    public Message deleteTopic(String id) {
        topics.remove(id);
        return new DeleteTopicMessage(id);
    }


}