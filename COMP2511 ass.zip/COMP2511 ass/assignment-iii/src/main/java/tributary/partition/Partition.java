package tributary.partition;

import product.Producer;
import tributary.event.Event;

import java.io.Serializable;
import java.util.LinkedList;

public class Partition implements Serializable {
    private LinkedList<Event> events;
    private Producer producer;
    private String partitonId;
    public Partition(String id){
        events = new LinkedList<>();
        this.partitonId = id;
    }

    public void addEvent(Event event){
        synchronized (events){
            events.add(event);
        }
    }


    public LinkedList<Event> getEvents() {
        synchronized (events){
            return events;
        }
    }

    public void setEvents(LinkedList<Event> events) {
        this.events = events;
    }

    public Producer getProducer() {
        return producer;
    }

    public String getPartitonId() {
        return partitonId;
    }


    public void setProducer(Producer producer) {
        this.producer = producer;
    }

    @Override
    public String toString() {
        return "Partition{" +
                "events=" + events.toString() +
                ", partitonId='" + partitonId + '\'' +
                '}';
    }
}
