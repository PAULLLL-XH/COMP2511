package tributary.event;

import java.io.Serializable;
import java.util.Date;

/**
 Headers

 Datetime created;

 ID;

 Payload Type;

 Source;

 Key; and

 Value. The value is an object containing relevant
 information for a topic. Considering information
 required for different topics may change, you should
 consider using a generic type here.



 */


public class Event<T> implements Serializable {
    private Date date;
    String ID;
    String Source;
    T value;

    public T getValue() {
        return value;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setValue(T value) {
//        System.out.println("value = " + value);
        this.value = value;
    }

    public void setSource(String source) {
        Source = source;
    }

    //    int offset; //


    @Override
    public String toString() {
        return "Event{" +
                "date=" + date +
                ", ID='" + ID + '\'' +
                ", Source='" + Source + '\'' +
                ", value=" + value +
                '}';
    }
}
