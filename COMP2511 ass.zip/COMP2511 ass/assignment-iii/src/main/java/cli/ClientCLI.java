package cli;

import tributary.TributaryServer;

public abstract class ClientCLI {
    public abstract void updateSever(TributaryServer tributaryServer) ;
}
