package pre;//package pre;
//
//import org.junit.jupiter.api.*;
//import tributary.message.*;
//
//import static org.junit.jupiter.api.Assertions.assertFalse;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import static util.TestUtil.*;
//
//@TestMethodOrder(MethodOrderer.OrderAnnotation. class)
//public class ProducerTest01 {
//
//
//    @Test
//    public void producerTest(){
//        setUp();
//        init();
//        //  create producer <id> <type> <allocation> Random
//        String inputLine = "create producer pr005 String Random";
//        Message message = producerCLI.func(inputLine);
//        assertTrue(message instanceof CreateProducerMessage);
//        assertTrue(((CreateProducerMessage) message).createdSuccess);
//
//        inputLine = "create producer pr002 Integer Random";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof CreateProducerMessage);
//        assertTrue(((CreateProducerMessage) message).createdSuccess);
//
//        inputLine = "create producer pr003 Stu Manual";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof CreateProducerMessage);
//        assertTrue(((CreateProducerMessage) message).createdSuccess);
//
//        inputLine = "create producer pr004 String xxx";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof CreateProducerMessage);
//        assertTrue(((CreateProducerMessage) message).createdSuccess);
//
//        //2
//        inputLine = "create producer pr001 String Manual";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof CreateProducerMessage);
//        assertFalse(((CreateProducerMessage) message).createdSuccess);
//
//        // 3
//        String path = "/Event1.json";
//        inputLine = "produce event pr001 t001 "+ path+" p001";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof ProduceEventMessage);
//        System.out.println("message1 = " + message);
//
//        path = "/Event1.json";
//        inputLine = "produce event pr001 t001 "+ path+" p001";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof ProduceEventMessage);
//        System.out.println("message2 = " + message);
//
//        path = "/EventInteger.json";
//        inputLine = "produce event pr002 t002 "+ path+" p003";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof ProduceEventMessage);
//        System.out.println("message3 = " + message);
//
//        path = "/EventStu.json";
//        inputLine = "produce event pr003 t003 "+ path+" p005";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof ProduceEventMessage);
//        System.out.println("message4 = " + message);
//
//        // 4
//        path = "/Event3.json";
//        inputLine = "produce event pr001 t001 "+ path+" 001";
//        message = producerCLI.func(inputLine);
//        assertFalse(message instanceof ProduceEventMessage);
//
//        path = "/Event3.json";
//        inputLine = "produce event pr001 t001 "+ path+" 004";
//        message = producerCLI.func(inputLine);
//        assertFalse(message instanceof ProduceEventMessage);
//
//        // 5
//         path = "/ParallelProduce.json";
//        // parallel produce /ParallelProduce.json
//         inputLine = "parallel produce "+path;
//         message = producerCLI.func(inputLine);
//        assertTrue(message instanceof ParallelProduceMessage);
//        ((ParallelProduceMessage) message).getMessages().forEach((message1 -> assertTrue(message1 instanceof ProduceEventMessage)));
////        System.out.println("message1 = " + message);
//
//        // 6
//        path = "/ParallelProduceFail.json";
//
//        inputLine = "parallel produce "+path;
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof ParallelProduceMessage);
//        ((ParallelProduceMessage) message).getMessages().forEach((message1 -> assertTrue(message1 instanceof ErrorMessage)));
//
//    }
//
//
//
//
//}
