package pre;//package pre;
//
//import org.junit.jupiter.api.Test;
//import tributary.message.*;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static util.TestUtil.*;
//import static util.TestUtil.consumerClientCLI;
//
//public class ConsumerTest01 {
//    @Test
//    public void consumerTest(){
//        setUp();
//        init();
//        String inputLine = "create consumer group g001 t001 Range";
////        Message message = tributaryConsumer.createConsumerGroup("g001", "t001", "Range");
//        Message message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof CreateConsumerGroupMessage);
//        assertTrue(((CreateConsumerGroupMessage) message).createdSuccess);
//
//        inputLine = "create consumer group g002 t001 RoundRobin";
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof CreateConsumerGroupMessage);
//        assertTrue(((CreateConsumerGroupMessage) message).createdSuccess);
//
//        // 2
//        // groupId duplicate
//        inputLine = "create consumer group g001 t001 Range";
////        Message message = tributaryConsumer.createConsumerGroup("g001", "t002", "Range");
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof CreateConsumerGroupMessage);
//        assertFalse(((CreateConsumerGroupMessage) message).createdSuccess);
//
//        inputLine = "create consumer group g003 t005 Range";
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof CreateConsumerGroupMessage);
//        assertFalse(((CreateConsumerGroupMessage) message).createdSuccess);
//
//        inputLine = "create consumer g001 c001";
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof CreateConsumerMessage);
//        assertTrue(((CreateConsumerMessage) message).createdSuccess);
//
//        inputLine = "create consumer g002 c001";
//        message = consumerClientCLI.func(inputLine);
//        System.out.println(message.toString());
//        assertTrue(message instanceof CreateConsumerMessage);
//        assertTrue(((CreateConsumerMessage) message).createdSuccess);
//
//        inputLine = "create consumer g001 c002";
//        message = consumerClientCLI.func(inputLine);
//        System.out.println(message.toString());
//        assertTrue(message instanceof CreateConsumerMessage);
//        assertTrue(((CreateConsumerMessage) message).createdSuccess);
//
//        inputLine = "create consumer g001 c003";
//        message = consumerClientCLI.func(inputLine);
//        System.out.println(message.toString());
//        assertTrue(message instanceof CreateConsumerMessage);
//        assertTrue(((CreateConsumerMessage) message).createdSuccess);
//
//        inputLine = "create consumer g001 c001";
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof CreateConsumerMessage);
//        assertFalse(((CreateConsumerMessage) message).createdSuccess);
//
//        inputLine = "delete consumer c001";
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof DeleteConsumerMessage);
//        assertTrue(((DeleteConsumerMessage) message).deletedSuccess);
//
//        inputLine = "delete consumer c001";
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof DeleteConsumerMessage);
//        assertFalse(((DeleteConsumerMessage) message).deletedSuccess);
//
//        inputLine = "consume event c002 p001";
//
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof ConsumeEventMessage);
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof ConsumeEventMessage);
//        message = consumerClientCLI.func(inputLine);
//
//        assertTrue(message instanceof ConsumeEventMessage);
//
//        inputLine = "consume event c001 p001";
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof ErrorMessage);
//
//        inputLine = "consume event c002 p003";
//        message = consumerClientCLI.func(inputLine);
//        inputLine = "consume event c003 p003";
//
//        assertTrue(message instanceof ErrorMessage);
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof ErrorMessage);
//
//        inputLine = "consume events c002 p001 3";
//
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof ConsumerEventsMessage);
//
//        ((ConsumerEventsMessage) message).getMessages().forEach( (message1 -> assertTrue(message1 instanceof ConsumeEventMessage)));
//
//        inputLine = "consume events c003 p001 3";
//
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof ConsumerEventsMessage);
//        ((ConsumerEventsMessage) message).getMessages().forEach( (message1 -> assertTrue(message1 instanceof ErrorMessage)));
//
//        inputLine = "consume events c002 p007 3";
//
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof ConsumerEventsMessage);
//        ((ConsumerEventsMessage) message).getMessages().forEach( (message1 -> assertTrue(message1 instanceof ErrorMessage)));
//
//        inputLine = "show topic t001";
//        Message message1 = tributaryCli.func(inputLine);
//        assertTrue(message1 instanceof ShowTopicMessage);
//
////        // partitionId duplicate
////        message = tributary.createPartition("t001", "p001");
//        inputLine = "show topic t001";
//        Message message2 = tributaryCli.func(inputLine);
//        assertTrue(message2 instanceof ShowTopicMessage);
//        assertEquals(message1, message2);
//
//        // parallel consume (<consumer>, <partition>)
//        // parallel consumer /ParallelConsumer.json
//        String path = "/ParallelConsumer.json";
//        inputLine = "parallel consumer "+path;
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof ParallelConsumerMessage);
////        ((ParallelConsumerMessage) message).getMessages().forEach((message1 -> System.out.println("message1 = " + message1)));
//        ((ParallelConsumerMessage) message).getMessages().forEach((message3 -> {System.out.println("message3 = " + message3);assertTrue(message3 instanceof ConsumeEventMessage);}));
////        System.out.println("message1 = " + message);
//
//        path = "/ParallelConsumerFail.json";
//        inputLine = "parallel consumer "+path;
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof ParallelConsumerMessage);
////        ((ParallelConsumerMessage) message).getMessages().forEach((message1 -> System.out.println("message1 = " + message1)));
//        ((ParallelConsumerMessage) message).getMessages().forEach((message3 -> {System.out.println("message3 = " + message3);assertTrue(message3 instanceof ErrorMessage);}));
////        System.out.println("message1 = " + message);
//
//        inputLine ="set consumer group rebalancing g001 RoundRobin";
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof RebalancingMessage);
//
//        inputLine ="set consumer group rebalancing g0001 RoundRobin";
//        message = consumerClientCLI.func(inputLine);
//        assertTrue(message instanceof ErrorMessage);
//
//
//        //16
//        inputLine = "playback c002 p002 0 3";
//        message = consumerClientCLI.func(inputLine);
//        System.out.println(message);
//        assertTrue(message instanceof ConsumerEventsMessage);
//
//        // 17
//        inputLine = "playback c002 p009 0 3";
//        message = consumerClientCLI.func(inputLine);
//        System.out.println(message);
//        assertTrue(message instanceof ErrorMessage);
////        ((ParallelConsumerMessage) message).getMessages().forEach((message1 -> System.out.println("message1 = " + message1)));
////        System.out.println("message1 = " + message);
//
//        inputLine = "playback c004 p001 0 3";
//        message = consumerClientCLI.func(inputLine);
//        System.out.println(message);
//        assertTrue(message instanceof ErrorMessage);
//
//    }
//}
