package pre;//package pre;
//import org.junit.jupiter.api.*;
//
//import tributary.message.*;
//
//import java.io.IOException;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import static util.TestUtil.*;
//
//
//@TestMethodOrder(MethodOrderer.OrderAnnotation. class)
//public class TributaryServerTest {
////    private static TributaryCLI tributaryCli;
//    // Feel free to delete/change this file, this is just here to give directory structure.
////    @BeforeEach
////    public void setUp(){
////        tributaryCli = new TributaryCLI();
////    }
//
//    @Test
//    @Tag("1-1")
//    @Order(1)
//    public void testCreateTopic() throws IOException {
//        setUp();
//        String inputLine = "create topic t004 String";
//        Message message = tributaryCli.func(inputLine);
////        Message message =  tributary.createTopic("t001", "String");
//        assertTrue(message instanceof CreateTopicMessage);
//        assertEquals( ((CreateTopicMessage) message).getId(), "t004");
//        assertEquals(((CreateTopicMessage) message).getType(), "String");
//    }
//
//    @Test
//    @Tag("1-2")
//    @Order(2)
//    public void testCreateTopicFail(){
////        Message message =tributary.createTopic("t001", "String");
//        String inputLine = "create topic t004 String";
//        Message message = tributaryCli.func(inputLine);
//        assertTrue(message instanceof ErrorMessage);
//    }
//
//    @Test
//    @Tag("1-3")
//    @Order(3)
//    public void testCreatePartition(){
////        Message message = tributary.createPartition("t001", "p001");
//        String inputLine = "create partition t004 p009";
//        Message message = tributaryCli.func(inputLine);
//        assertTrue(message instanceof CreatePartitionMessage);
//
//        assertEquals(((CreatePartitionMessage) message).getTopicId(), "t004");
//        assertEquals(((CreatePartitionMessage) message).getId(), "p009");
//    }
//
//    @Test
//    @Tag("1-4")
//    @Order(4)
//    public void testCreatePartitionFail(){
//        // topic is not exist
////        Message message = tributary.createPartition("t002", "p001");
//        String inputLine = "create partition t009 p009";
//        Message message = tributaryCli.func(inputLine);
//
//        assertTrue(message instanceof ErrorMessage);
//
////        // partitionId duplicate
////        message = tributary.createPartition("t001", "p001");
//        inputLine = "create partition t004 p009";
//        message = tributaryCli.func(inputLine);
//        assertTrue(message instanceof ErrorMessage);
//    }
//
//    @Test
//    @Tag("1-5")
//    @Order(5)
//    public void testShowTopic(){
//        // topic is not exist
//        String inputLine = "show topic t004";
//        Message message1 = tributaryCli.func(inputLine);
//        assertTrue(message1 instanceof ShowTopicMessage);
//
////        // partitionId duplicate
////        message = tributary.createPartition("t001", "p001");
//        inputLine = "show topic t004";
//        Message message2 = tributaryCli.func(inputLine);
//        assertTrue(message2 instanceof ShowTopicMessage);
//        assertEquals(message1, message2);
//    }
//
//
//    @Test
//    @Tag("1-6")
//    @Order(6)
//    public void testShowTopicFail(){
//        // topic is not exist
//        String inputLine = "show topic t009";
//        Message message1 = tributaryCli.func(inputLine);
//        assertTrue(message1 instanceof ErrorMessage);
//    }
//
//
//
//}