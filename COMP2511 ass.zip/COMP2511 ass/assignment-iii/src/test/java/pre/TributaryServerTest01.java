package pre;//package pre;
//
//import org.junit.jupiter.api.*;
//import tributary.message.*;
//
//import java.io.IOException;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import static util.TestUtil.setUp;
//import static util.TestUtil.tributaryCli;
//
//
//@TestMethodOrder(MethodOrderer.OrderAnnotation. class)
//public class TributaryServerTest01 {
////    private static TributaryCLI tributaryCli;
//    // Feel free to delete/change this file, this is just here to give directory structure.
////    @BeforeEach
////    public void setUp(){
////        tributaryCli = new TributaryCLI();
////    }
//
//    @Test
//    public void testCreateTopic() throws IOException {
//        setUp();
//        String inputLine = "create topic t004 String";
//        Message message = tributaryCli.func(inputLine);
////        Message message =  tributary.createTopic("t001", "String");
//        assertTrue(message instanceof CreateTopicMessage);
//        assertEquals( ((CreateTopicMessage) message).getId(), "t004");
//        assertEquals(((CreateTopicMessage) message).getType(), "String");
//
//        // 2
//        inputLine = "create topic t004 String";
//        message = tributaryCli.func(inputLine);
//        assertTrue(message instanceof ErrorMessage);
//
//        // 3
//        inputLine = "create partition t004 p009";
//        message = tributaryCli.func(inputLine);
//        assertTrue(message instanceof CreatePartitionMessage);
//
//        assertEquals(((CreatePartitionMessage) message).getTopicId(), "t004");
//        assertEquals(((CreatePartitionMessage) message).getId(), "p009");
//
//        // 4
//        inputLine = "create partition t009 p009";
//        message = tributaryCli.func(inputLine);
//
//        assertTrue(message instanceof ErrorMessage);
//
////        // partitionId duplicate
////        message = tributary.createPartition("t001", "p001");
//        inputLine = "create partition t004 p009";
//        message = tributaryCli.func(inputLine);
//        assertTrue(message instanceof ErrorMessage);
//
//        // 5
//        inputLine = "show topic t004";
//        Message message1 = tributaryCli.func(inputLine);
//        assertTrue(message1 instanceof ShowTopicMessage);
//
////        // partitionId duplicate
////        message = tributary.createPartition("t001", "p001");
//        inputLine = "show topic t004";
//        Message message2 = tributaryCli.func(inputLine);
//        assertTrue(message2 instanceof ShowTopicMessage);
//        assertEquals(message1, message2);
//
//         inputLine = "show topic t009";
//         message1 = tributaryCli.func(inputLine);
//        assertTrue(message1 instanceof ErrorMessage);
//
//    }
//
//
//
//
//}