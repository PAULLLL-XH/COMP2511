package pre;//package pre;
//
//import org.junit.jupiter.api.*;
//import tributary.message.*;
//
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import static org.junit.jupiter.api.Assertions.assertFalse;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static util.TestUtil.*;
//
//@TestMethodOrder(MethodOrderer.OrderAnnotation. class)
//public class ConsumerTest {
////    private static final TributaryConsumer tributaryConsumer = TributaryConsumer.getInstance();
////    private static TributaryCLI tributaryCli;
////    private static ConsumerCLI consumerCLI;
////    private static ProducerCLI producerCLI;
////
////    public void setUp(){
////        tributaryCli = new TributaryCLI();
////        producerCLI = new ProducerCLI();
////        consumerCLI = new ConsumerCLI();
////
////        init(tributaryCli);
////    }
////
////    private void init(TributaryCLI tributaryCli) {
////        String createTopic1 = "create topic t001 String";
////        String createPartition1 = "create partition t001 p001";
////        String createPartition2 = "create partition t001 p002";
////        tributaryCli.func(createTopic1);
////        tributaryCli.func(createPartition1);
////        tributaryCli.func(createPartition2);
////
////        String createProducer1 = "create producer pr001 String Random";
////        producerCLI.func(createProducer1);
////        String path = "Event1.json";
////        String produce1 = "produce event pr001 t001 "+ path+" p001";
////        for (int i = 0; i < 10; i++) {
////            producerCLI.func(produce1);
////        }
////    }
//
//    @Test
//    @Tag("2-1")
//    @Order(1)
//    public void testCreateConsumerGroup(){
//        setUp();
//        init();
//        String inputLine = "create consumer group g001 t001 Range";
////        Message message = tributaryConsumer.createConsumerGroup("g001", "t001", "Range");
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof CreateConsumerGroupMessage);
//        assertTrue(((CreateConsumerGroupMessage) message).createdSuccess);
//
//        inputLine = "create consumer group g002 t001 RoundRobin";
//        message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof CreateConsumerGroupMessage);
//        assertTrue(((CreateConsumerGroupMessage) message).createdSuccess);
//    }
//
//    @Test
//    @Tag("2-2")
//    @Order(2)
//    public void testCreateConsumerGroupFail(){
//        // groupId duplicate
//        String inputLine = "create consumer group g001 t001 Range";
////        Message message = tributaryConsumer.createConsumerGroup("g001", "t002", "Range");
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof CreateConsumerGroupMessage);
//        assertFalse(((CreateConsumerGroupMessage) message).createdSuccess);
//
//        inputLine = "create consumer group g003 t005 Range";
//        message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof CreateConsumerGroupMessage);
//        assertFalse(((CreateConsumerGroupMessage) message).createdSuccess);
//    }
//
//    @Test
//    @Tag("2-3")
//    @Order(3)
//    public void testCreateConsumer(){
////        Message message = tributaryConsumer.createConsumer("g001", "c001");
//        String inputLine = "create consumer g001 c001";
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof CreateConsumerMessage);
//        assertTrue(((CreateConsumerMessage) message).createdSuccess);
//
//        inputLine = "create consumer g002 c001";
//        message = consumerCLI.func(inputLine);
//        System.out.println(message.toString());
//        assertTrue(message instanceof CreateConsumerMessage);
//        assertTrue(((CreateConsumerMessage) message).createdSuccess);
//
//        inputLine = "create consumer g001 c002";
//        message = consumerCLI.func(inputLine);
//        System.out.println(message.toString());
//        assertTrue(message instanceof CreateConsumerMessage);
//        assertTrue(((CreateConsumerMessage) message).createdSuccess);
//
//        inputLine = "create consumer g001 c003";
//        message = consumerCLI.func(inputLine);
//        System.out.println(message.toString());
//        assertTrue(message instanceof CreateConsumerMessage);
//        assertTrue(((CreateConsumerMessage) message).createdSuccess);
//    }
//
//    @Test
//    @Tag("2-4")
//    @Order(4)
//    public void testCreateConsumerFail(){
////        Message message = tributaryConsumer.createConsumer("g001", "c001");
//        // consumerGroup  groupId duplicate
//        String inputLine = "create consumer g001 c001";
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof CreateConsumerMessage);
//        assertFalse(((CreateConsumerMessage) message).createdSuccess);
//    }
//
//
//    @Test
//    @Tag("2-5")
//    @Order(5)
//    public void testDeleteConsumer(){
////        Message message = tributaryConsumer.createConsumer("g001", "c001");
//        // consumerGroup  groupId duplicate
//        String inputLine = "delete consumer c001";
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof DeleteConsumerMessage);
//        assertTrue(((DeleteConsumerMessage) message).deletedSuccess);
//    }
//
//    @Test
//    @Tag("2-6")
//    @Order(6)
//    public void testDeleteConsumerFail(){
////        Message message = tributaryConsumer.createConsumer("g001", "c001");
//        // consumerGroup  groupId duplicate
//        String inputLine = "delete consumer c001";
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof DeleteConsumerMessage);
//        assertFalse(((DeleteConsumerMessage) message).deletedSuccess);
//    }
//
//
//    @Test
//    @Tag("2-7")
//    @Order(7)
//    public void testConsumeEvent(){
//        // consume event <consumer> <partition>
//        // consumerGroup  groupId duplicate
//        String inputLine = "consume event c002 p001";
//
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof ConsumeEventMessage);
//        message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof ConsumeEventMessage);
//        message = consumerCLI.func(inputLine);
//
//        assertTrue(message instanceof ConsumeEventMessage);
//    }
//
//    @Test
//    @Tag("2-8")
//    @Order(8)
//    public void testConsumeEventFail(){
//        // consume event <consumer> <partition>
//        // consumerGroup  groupId duplicate
//        String inputLine = "consume event c001 p001";
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof ErrorMessage);
//
//        inputLine = "consume event c002 p003";
//        message = consumerCLI.func(inputLine);
//        inputLine = "consume event c003 p003";
//
//        assertTrue(message instanceof ErrorMessage);
//        message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof ErrorMessage);
//    }
//
//    //consume events <consumer> <partition> <number of events>
//
//
//    @Test
//    @Tag("2-9")
//    @Order(9)
//    public void testConsumeEvents(){
//        // consume event <consumer> <partition>
//        // consumerGroup  groupId duplicate
//        String inputLine = "consume events c002 p001 3";
//
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof ConsumerEventsMessage);
//
//        ((ConsumerEventsMessage) message).getMessages().forEach( (message1 -> assertTrue(message1 instanceof ConsumeEventMessage)));
//    }
//
//    @Test
//    @Tag("2-10")
//    @Order(10)
//    public void testConsumeEventsFail(){
//        // consume event <consumer> <partition>
//        // in a consumerGroup  groupId duplicate
//        String inputLine = "consume events c003 p001 3";
//
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof ConsumerEventsMessage);
//        ((ConsumerEventsMessage) message).getMessages().forEach( (message1 -> assertTrue(message1 instanceof ErrorMessage)));
//
//        inputLine = "consume events c002 p007 3";
//
//        message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof ConsumerEventsMessage);
//        ((ConsumerEventsMessage) message).getMessages().forEach( (message1 -> assertTrue(message1 instanceof ErrorMessage)));
//
//
//
//    }
//
//    // show consumer group <group>
//
//    @Test
//    @Tag("2-11")
////    @DisplayName("showConsumergroups")
//    @Order(11)
//    public void testShowConsumergroups(){
//        // topic is not exist
//        String inputLine = "show topic t001";
//        Message message1 = tributaryCli.func(inputLine);
//        assertTrue(message1 instanceof ShowTopicMessage);
//
////        // partitionId duplicate
////        message = tributary.createPartition("t001", "p001");
//        inputLine = "show topic t001";
//        Message message2 = tributaryCli.func(inputLine);
//        assertTrue(message2 instanceof ShowTopicMessage);
//        assertEquals(message1, message2);
//    }
//
//
//    // show consumer group <group>
//
//    @Test
//    @Tag("2-12")
//    @Order(12)
//    public void testParallelConsumer(){
//        // parallel consume (<consumer>, <partition>)
//        String path = "/ParallelConsumer.json";
//        String inputLine = "parallel consumer "+path;
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof ParallelConsumerMessage);
////        ((ParallelConsumerMessage) message).getMessages().forEach((message1 -> System.out.println("message1 = " + message1)));
//        ((ParallelConsumerMessage) message).getMessages().forEach((message1 -> {System.out.println("message1 = " + message1);assertTrue(message1 instanceof ConsumeEventMessage);}));
////        System.out.println("message1 = " + message);
//
//    }
//
//    @Test
//    @Tag("2-13")
//    @Order(13)
//    public void testParallelConsumerFail(){
//        // parallel consume (<consumer>, <partition>)
//        String path = "/ParallelConsumerFail.json";
//        String inputLine = "parallel consumer "+path;
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof ParallelConsumerMessage);
////        ((ParallelConsumerMessage) message).getMessages().forEach((message1 -> System.out.println("message1 = " + message1)));
//        ((ParallelConsumerMessage) message).getMessages().forEach((message1 -> {System.out.println("message1 = " + message1);assertTrue(message1 instanceof ErrorMessage);}));
////        System.out.println("message1 = " + message);
//
//    }
//
//    @Test
//    @Tag("2-14")
//    @Order(14)
//    public void testRebalancing(){
//        //set consumer group rebalancing <group> <rebalancing>
//        // parallel consume (<consumer>, <partition>)
//        String inputLine ="set consumer group rebalancing g001 RoundRobin";
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof RebalancingMessage);
//
//    }
//
//    @Test
//    @Tag("2-15")
//    @Order(15)
//    public void testRebalancingFail(){
//        //set consumer group rebalancing <group> <rebalancing>
//        // parallel consume (<consumer>, <partition>)
//        String inputLine ="set consumer group rebalancing g0001 RoundRobin";
//        Message message = consumerCLI.func(inputLine);
//        assertTrue(message instanceof ErrorMessage);
//
//    }
//
//    @Test
//    @Tag("2-16")
////    @DisplayName("testPlayback")
//    @Order(16)
//    public void testPlayback(){
//        // parallel consume (<consumer>, <partition>)
//        // playback <consumer> <partition> <offset> <number of events>
//        String inputLine = "playback c002 p002 0 3";
//        Message message = consumerCLI.func(inputLine);
//        System.out.println(message);
//        assertTrue(message instanceof ConsumerEventsMessage);
////        ((ParallelConsumerMessage) message).getMessages().forEach((message1 -> System.out.println("message1 = " + message1)));
////        System.out.println("message1 = " + message);
//    }
//
//    @Test
//    @Tag("2-17")
////    @DisplayName("testPlaybackFail")
//    @Order(17)
//    public void testPlaybackFail(){
//        // parallel consume (<consumer>, <partition>)
//        // playback <consumer> <partition> <offset> <number of events>
//        String inputLine = "playback c002 p009 0 3";
//        Message message = consumerCLI.func(inputLine);
//        System.out.println(message);
//        assertTrue(message instanceof ErrorMessage);
////        ((ParallelConsumerMessage) message).getMessages().forEach((message1 -> System.out.println("message1 = " + message1)));
////        System.out.println("message1 = " + message);
//
//        inputLine = "playback c004 p001 0 3";
//        message = consumerCLI.func(inputLine);
//        System.out.println(message);
//        assertTrue(message instanceof ErrorMessage);
//    }
//
//}
