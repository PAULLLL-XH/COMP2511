package pre;//package pre;
//
//import org.junit.jupiter.api.*;
//import tributary.message.*;
//
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import static org.junit.jupiter.api.Assertions.assertFalse;
//import static util.TestUtil.*;
//
//@TestMethodOrder(MethodOrderer.OrderAnnotation. class)
//public class ProducerTest {
////    private static final TributaryConsumer tributaryConsumer = TributaryConsumer.getInstance();
////    private static TributaryCLI tributaryCli;
////    private static ProducerCLI producerCLI;
//
//
////    public void setUp(){
////        tributaryCli = new TributaryCLI();
////        producerCLI = new ProducerCLI();
////
////        init(tributaryCli);
////    }
////
////    private void init(TributaryCLI tributaryCli) {
////        String createTopic1 = "create topic t001 String";
////        String createPartition1 = "create partition t001 p001";
////        String createPartition2 = "create partition t001 p002";
////        tributaryCli.func(createTopic1);
////        tributaryCli.func(createPartition1);
////        tributaryCli.func(createPartition2);
////
////        String createTopic2 = "create topic t002 Integer";
////        String createPartition3 = "create partition t002 p003";
////        String createPartition4 = "create partition t002 p004";
////        tributaryCli.func(createTopic2);
////        tributaryCli.func(createPartition3);
////        tributaryCli.func(createPartition4);
////
////        String createTopic3 = "create topic t003 Stu";
////        String createPartition5 = "create partition t003 p005";
////        String createPartition6 = "create partition t003 p006";
////        tributaryCli.func(createTopic3);
////        tributaryCli.func(createPartition5);
////        tributaryCli.func(createPartition6);
////    }
//
//    @Test
//    @Tag("3-1")
//    @Order(1)
//    public void testCreateProducer(){
//        setUp();
//        init();
//        //  create producer <id> <type> <allocation> Random
//        String inputLine = "create producer pr005 String Random";
//        Message message = producerCLI.func(inputLine);
//        assertTrue(message instanceof CreateProducerMessage);
//        assertTrue(((CreateProducerMessage) message).createdSuccess);
//
//        inputLine = "create producer pr002 Integer Random";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof CreateProducerMessage);
//        assertTrue(((CreateProducerMessage) message).createdSuccess);
//
//        inputLine = "create producer pr003 Stu Manual";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof CreateProducerMessage);
//        assertTrue(((CreateProducerMessage) message).createdSuccess);
//
//        inputLine = "create producer pr004 String xxx";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof CreateProducerMessage);
//        assertTrue(((CreateProducerMessage) message).createdSuccess);
//
//    }
//
//    @Test
//    @Tag("3-2")
//    @Order(2)
//    public void testCreateProducerFail(){
//        //  create producer <id> <type> <allocation> Random
//        // producerId duplicate
//        String inputLine = "create producer pr001 String Manual";
//        Message message = producerCLI.func(inputLine);
//        assertTrue(message instanceof CreateProducerMessage);
//        assertFalse(((CreateProducerMessage) message).createdSuccess);
//    }
//
//    //produce event <producer> <topic> <event> <partition>
//    @Test
//    @Tag("3-3")
//    @Order(3)
//    public void testProduceEvent(){
//        String path = "/Event1.json";
//        String inputLine = "produce event pr001 t001 "+ path+" p001";
//        Message message = producerCLI.func(inputLine);
//        assertTrue(message instanceof ProduceEventMessage);
//        System.out.println("message1 = " + message);
//
//        path = "/Event1.json";
//        inputLine = "produce event pr001 t001 "+ path+" p001";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof ProduceEventMessage);
//        System.out.println("message2 = " + message);
//
//        path = "/EventInteger.json";
//        inputLine = "produce event pr002 t002 "+ path+" p003";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof ProduceEventMessage);
//        System.out.println("message3 = " + message);
//
//        path = "/EventStu.json";
//        inputLine = "produce event pr003 t003 "+ path+" p005";
//        message = producerCLI.func(inputLine);
//        assertTrue(message instanceof ProduceEventMessage);
//        System.out.println("message4 = " + message);
//
//    }
//
//    //produce event <producer> <topic> <event> <partition>
//    @Test
//    @Tag("3-4")
//    @Order(4)
//    public void testProduceEventFali(){
//        String path = "/Event3.json";
//        String inputLine = "produce event pr001 t001 "+ path+" 001";
//        Message message = producerCLI.func(inputLine);
//        assertFalse(message instanceof ProduceEventMessage);
//
//        path = "/Event3.json";
//        inputLine = "produce event pr001 t001 "+ path+" 004";
//        message = producerCLI.func(inputLine);
//        assertFalse(message instanceof ProduceEventMessage);
//    }
//
//    //produce event <producer> <topic> <event> <partition>
//    @Test
//    @Tag("3-5")
//    @Order(5)
//    public void testParallelProduceEvent(){
//        // parallel produce (<producer>, <topic>, <event>), ...
//        String path = "/ParallelProduce.json";
//        String inputLine = "parallel produce "+path;
//        Message message = producerCLI.func(inputLine);
//        assertTrue(message instanceof ParallelProduceMessage);
//        ((ParallelProduceMessage) message).getMessages().forEach((message1 -> assertTrue(message1 instanceof ProduceEventMessage)));
////        System.out.println("message1 = " + message);
//    }
//
//    //produce event <producer> <topic> <event> <partition>
//    @Test
//    @Tag("3-6")
//    @Order(6)
//    public void testParallelProduceEventFail(){
//        // parallel produce (<producer>, <topic>, <event>), ...
//        String path = "/ParallelProduceFail.json";
//        String inputLine = "parallel produce "+path;
//        Message message = producerCLI.func(inputLine);
//        assertTrue(message instanceof ParallelProduceMessage);
//        ((ParallelProduceMessage) message).getMessages().forEach((message1 -> assertTrue(message1 instanceof ErrorMessage)));
////        System.out.println("message1 = " + message);
//    }
//
//
//}
