package util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RequstTest {

    @Test
    void getRequst() {
        Requst requst = new Requst();
        assertEquals(requst.getRequst(), "need Tributary");
        assertFalse(requst.toString().isBlank());
    }


}