package util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StuTest {

    @Test
    void testToString() {
        Stu stu = new Stu("xiaoming", 13);
        assertEquals(stu.name, "xiaoming");
        assertEquals(stu.age,13);
        assertFalse(stu.toString().isBlank());
    }
}