package util;//package util;
//
//import consumer.ConsumerClientCLI;
//import consumer.TributaryConsumer;
//import product.ProducerClientCLI;
//import tributary.TributaryCLI;
//
//public class TestUtil {
//    static public final TributaryConsumer tributaryConsumer = TributaryConsumer.getInstance();
//    static public TributaryCLI tributaryCli;
//    static public ConsumerClientCLI consumerClientCLI;
//    static public ProducerClientCLI producerCLI;
//    static public boolean isSetUp;
//    static public boolean isInit;
//    public static synchronized void setUp(){
//        if (isSetUp){
//            return;
//        }
//        tributaryCli = new TributaryCLI();
//        producerCLI = new ProducerClientCLI();
//        consumerClientCLI = new ConsumerClientCLI();
//        isSetUp = true;
//    }
//
//    public static synchronized void init() {
//        if (isInit){
//            return;
//        }
//        String createTopic1 = "create topic t001 String";
//        String createPartition1 = "create partition t001 p001";
//        String createPartition2 = "create partition t001 p002";
//        tributaryCli.func(createTopic1);
//        tributaryCli.func(createPartition1);
//        tributaryCli.func(createPartition2);
//
//        String createProducer1 = "create producer pr001 String Random";
//        producerCLI.func(createProducer1);
//        String path = "/Event1.json";
//        // produce event pr001 t001 /Event1.json p001
//
//        String produce1 = "produce event pr001 t001 "+ path+" p001";
//        for (int i = 0; i < 10; i++) {
//            producerCLI.func(produce1);
//        }
//
//
//        String createTopic2 = "create topic t002 Integer";
//        String createPartition3 = "create partition t002 p003";
//        String createPartition4 = "create partition t002 p004";
//        tributaryCli.func(createTopic2);
//        tributaryCli.func(createPartition3);
//        tributaryCli.func(createPartition4);
//
//        String createTopic3 = "create topic t003 Stu";
//        String createPartition5 = "create partition t003 p005";
//        String createPartition6 = "create partition t003 p006";
//        tributaryCli.func(createTopic3);
//        tributaryCli.func(createPartition5);
//        tributaryCli.func(createPartition6);
//
//        isInit = true;
//    }
//
//}
