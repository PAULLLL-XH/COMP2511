package connect;

import consumer.ConsumerClientCLI;
import org.junit.jupiter.api.Test;
import product.ProducerClientCLI;
import tributary.TributaryServer;
import util.ClientSend;
import util.ClientUpdate;
import util.SeverConnect;

public class ConnectTest {
    @Test
    public void connectTest1(){

        SeverConnect severConnect = new SeverConnect(TributaryServer.getInstance(),8888);
        severConnect.start();

        new ClientUpdate(new ProducerClientCLI(),8888).start();
        new ClientSend(new ConsumerClientCLI(),TributaryServer.getInstance(),8888).start();

    }
}
