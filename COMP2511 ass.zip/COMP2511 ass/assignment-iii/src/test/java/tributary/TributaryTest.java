package tributary;

import consumer.ConsumerClientCLI;
import org.junit.jupiter.api.Test;
import product.ProducerClientCLI;
import tributary.message.*;
import util.ClientSend;
import util.ClientUpdate;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertFalse;

public class TributaryTest {
    @Test
    public void TestTributaryTest() throws IOException {

        TributaryCLI tributaryCli = new TributaryCLI();
        TributaryCLI.severConnect.start();
        String inputLine = "create topic t004 String";
        Message message = tributaryCli.func(inputLine);
//        Message message =  tributary.createTopic("t001", "String");
        assertTrue(message instanceof CreateTopicMessage);
        assertEquals( ((CreateTopicMessage) message).getId(), "t004");
        assertEquals(((CreateTopicMessage) message).getType(), "String");

        // 2
        inputLine = "create topic t004 String";
        message = tributaryCli.func(inputLine);
        assertTrue(message instanceof ErrorMessage);

        // 3
        inputLine = "create partition t004 p009";
        message = tributaryCli.func(inputLine);
        assertTrue(message instanceof CreatePartitionMessage);

        assertEquals(((CreatePartitionMessage) message).getTopicId(), "t004");
        assertEquals(((CreatePartitionMessage) message).getId(), "p009");

        // 4
        inputLine = "create partition t009 p009";
        message = tributaryCli.func(inputLine);

        assertTrue(message instanceof ErrorMessage);

//        // partitionId duplicate
//        message = tributary.createPartition("t001", "p001");
        inputLine = "create partition t004 p009";
        message = tributaryCli.func(inputLine);
        assertTrue(message instanceof ErrorMessage);

        // 5
        inputLine = "show topic t004";
        Message message1 = tributaryCli.func(inputLine);
        assertTrue(message1 instanceof ShowTopicMessage);

//        // partitionId duplicate
//        message = tributary.createPartition("t001", "p001");
        inputLine = "show topic t004";
        Message message2 = tributaryCli.func(inputLine);
        assertTrue(message2 instanceof ShowTopicMessage);
        assertEquals(message1, message2);

        inputLine = "show topic t009";
        message1 = tributaryCli.func(inputLine);
        assertTrue(message1 instanceof ErrorMessage);


        // === init() =====
        String createTopic1 = "create topic t001 String";
        String createPartition1 = "create partition t001 p001";
        String createPartition2 = "create partition t001 p002";
        tributaryCli.func(createTopic1);
        tributaryCli.func(createPartition1);
        tributaryCli.func(createPartition2);

        String createTopic2 = "create topic t002 Integer";
        String createPartition3 = "create partition t002 p003";
        String createPartition4 = "create partition t002 p004";
        tributaryCli.func(createTopic2);
        tributaryCli.func(createPartition3);
        tributaryCli.func(createPartition4);

        String createTopic3 = "create topic t003 Stu";
        String createPartition5 = "create partition t003 p005";
        String createPartition6 = "create partition t003 p006";
        tributaryCli.func(createTopic3);
        tributaryCli.func(createPartition5);
        tributaryCli.func(createPartition6);

        ProducerClientCLI producerCLI = new ProducerClientCLI();
        // communication
        ClientUpdate clientUpdate = new ClientUpdate(producerCLI);
        clientUpdate.start();
        try {
            clientUpdate.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
//            updateTributaryServer();
        producerCLI.updateProducerServer(tributaryCli.getTributaryServer());
//

        String createProducer1 = "create producer pr001 String Random";
        producerCLI.func(createProducer1);
        String path = "/Event1.json";
        // produce event pr001 t001 /Event1.json p001

        String produce1 = "produce event pr001 t001 "+ path+" p001";
        for (int i = 0; i < 10; i++) {
            producerCLI.func(produce1);
        }

        // === init end =====

        inputLine = "create producer pr005 String Random";
        message = producerCLI.func(inputLine);
        assertTrue(message instanceof CreateProducerMessage);
        assertTrue(((CreateProducerMessage) message).createdSuccess);

        inputLine = "create producer pr002 Integer Random";
        message = producerCLI.func(inputLine);
        assertTrue(message instanceof CreateProducerMessage);
        assertTrue(((CreateProducerMessage) message).createdSuccess);

        inputLine = "create producer pr003 Stu Manual";
        message = producerCLI.func(inputLine);
        assertTrue(message instanceof CreateProducerMessage);
        assertTrue(((CreateProducerMessage) message).createdSuccess);

        inputLine = "create producer pr004 String xxx";
        message = producerCLI.func(inputLine);
        assertTrue(message instanceof CreateProducerMessage);
        assertTrue(((CreateProducerMessage) message).createdSuccess);

        //2
        inputLine = "create producer pr001 String Manual";
        message = producerCLI.func(inputLine);
        assertTrue(message instanceof CreateProducerMessage);
        assertFalse(((CreateProducerMessage) message).createdSuccess);

        // 3
        path = "/Event1.json";
        inputLine = "produce event pr001 t001 "+ path+" p001";
        message = producerCLI.func(inputLine);
        assertTrue(message instanceof ProduceEventMessage);
        System.out.println("message1 = " + message);

        path = "/Event1.json";
        inputLine = "produce event pr001 t001 "+ path+" p001";
        message = producerCLI.func(inputLine);
        assertTrue(message instanceof ProduceEventMessage);
        System.out.println("message2 = " + message);

        path = "/EventInteger.json";
        inputLine = "produce event pr002 t002 "+ path+" p003";
        message = producerCLI.func(inputLine);
        assertTrue(message instanceof ProduceEventMessage);
        System.out.println("message3 = " + message);

        path = "/EventStu.json";
        inputLine = "produce event pr003 t003 "+ path+" p005";
        message = producerCLI.func(inputLine);
        assertTrue(message instanceof ProduceEventMessage);
        System.out.println("message4 = " + message);

        // 4
        path = "/Event3.json";
        inputLine = "produce event pr001 t001 "+ path+" 001";
        message = producerCLI.func(inputLine);
        assertFalse(message instanceof ProduceEventMessage);

        path = "/Event3.json";
        inputLine = "produce event pr001 t001 "+ path+" 004";
        message = producerCLI.func(inputLine);
        assertFalse(message instanceof ProduceEventMessage);

        // 5
        path = "/ParallelProduce.json";
        // parallel produce /ParallelProduce.json
        inputLine = "parallel produce "+path;
        message = producerCLI.func(inputLine);
        assertTrue(message instanceof ParallelProduceMessage);
        ((ParallelProduceMessage) message).getMessages().forEach((message9-> assertTrue(message9 instanceof ProduceEventMessage)));
//        System.out.println("message1 = " + message);

        // 6
        path = "/ParallelProduceFail.json";

        inputLine = "parallel produce "+path;
        message = producerCLI.func(inputLine);
        assertTrue(message instanceof ParallelProduceMessage);
        ((ParallelProduceMessage) message).getMessages().forEach((message9 -> assertTrue(message9 instanceof ErrorMessage)));

        // send to server
        new ClientSend(producerCLI, producerCLI.getTributaryServer()).start();



        // consumer test
        ConsumerClientCLI consumerClientCLI = new ConsumerClientCLI();
        ClientUpdate clientUpdate2 = new ClientUpdate(consumerClientCLI);
        clientUpdate2.start();
        try {
            clientUpdate2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
//            updateTributaryServer();
        consumerClientCLI.updateConsumerSever(consumerClientCLI.getTributaryServer());


        inputLine = "create consumer group g001 t001 Range";
//        Message message = tributaryConsumer.createConsumerGroup("g001", "t001", "Range");
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof CreateConsumerGroupMessage);
        assertTrue(((CreateConsumerGroupMessage) message).createdSuccess);

        inputLine = "create consumer group g002 t001 RoundRobin";
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof CreateConsumerGroupMessage);
        assertTrue(((CreateConsumerGroupMessage) message).createdSuccess);

        // 2
        // groupId duplicate
        inputLine = "create consumer group g001 t001 Range";
//        Message message = tributaryConsumer.createConsumerGroup("g001", "t002", "Range");
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof CreateConsumerGroupMessage);
        assertFalse(((CreateConsumerGroupMessage) message).createdSuccess);

        inputLine = "create consumer group g003 t005 Range";
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof CreateConsumerGroupMessage);
        assertFalse(((CreateConsumerGroupMessage) message).createdSuccess);

        inputLine = "create consumer g001 c001";
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof CreateConsumerMessage);
        assertTrue(((CreateConsumerMessage) message).createdSuccess);

        inputLine = "create consumer g002 c001";
        message = consumerClientCLI.func(inputLine);
        System.out.println(message.toString());
        assertTrue(message instanceof CreateConsumerMessage);
        assertTrue(((CreateConsumerMessage) message).createdSuccess);

        inputLine = "create consumer g001 c002";
        message = consumerClientCLI.func(inputLine);
        System.out.println(message.toString());
        assertTrue(message instanceof CreateConsumerMessage);
        assertTrue(((CreateConsumerMessage) message).createdSuccess);

        inputLine = "create consumer g001 c003";
        message = consumerClientCLI.func(inputLine);
        System.out.println(message.toString());
        assertTrue(message instanceof CreateConsumerMessage);
        assertTrue(((CreateConsumerMessage) message).createdSuccess);

        inputLine = "create consumer g001 c001";
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof CreateConsumerMessage);
        assertFalse(((CreateConsumerMessage) message).createdSuccess);

        inputLine = "delete consumer c001";
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof DeleteConsumerMessage);
        assertTrue(((DeleteConsumerMessage) message).deletedSuccess);

        inputLine = "delete consumer c001";
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof DeleteConsumerMessage);
        assertFalse(((DeleteConsumerMessage) message).deletedSuccess);

        inputLine = "consume event c002 p001";

        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof ConsumeEventMessage);
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof ConsumeEventMessage);
        message = consumerClientCLI.func(inputLine);

        assertTrue(message instanceof ConsumeEventMessage);

        inputLine = "consume event c001 p001";
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof ErrorMessage);

        inputLine = "consume event c002 p003";
        message = consumerClientCLI.func(inputLine);
        inputLine = "consume event c003 p003";

        assertTrue(message instanceof ErrorMessage);
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof ErrorMessage);

        inputLine = "consume events c002 p001 3";

        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof ConsumerEventsMessage);

        ((ConsumerEventsMessage) message).getMessages().forEach( (message3 -> assertTrue(message3 instanceof ConsumeEventMessage)));

        inputLine = "consume events c003 p001 3";

        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof ConsumerEventsMessage);
        ((ConsumerEventsMessage) message).getMessages().forEach( (message3 -> assertTrue(message3 instanceof ErrorMessage)));

        inputLine = "consume events c002 p007 3";

        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof ConsumerEventsMessage);
        ((ConsumerEventsMessage) message).getMessages().forEach( (message3 -> assertTrue(message3 instanceof ErrorMessage)));

        inputLine = "show topic t001";
        message1 = tributaryCli.func(inputLine);
        assertTrue(message1 instanceof ShowTopicMessage);

//        // partitionId duplicate
//        message = tributary.createPartition("t001", "p001");
        inputLine = "show topic t001";
        message2 = tributaryCli.func(inputLine);
        assertTrue(message2 instanceof ShowTopicMessage);
        assertEquals(message1, message2);

        // parallel consume (<consumer>, <partition>)
        // parallel consumer /ParallelConsumer.json
        path = "/ParallelConsumer.json";
        inputLine = "parallel consumer "+path;
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof ParallelConsumerMessage);
//        ((ParallelConsumerMessage) message).getMessages().forEach((message1 -> System.out.println("message1 = " + message1)));
        ((ParallelConsumerMessage) message).getMessages().forEach((message3 -> {System.out.println("message3 = " + message3);assertTrue(message3 instanceof ConsumeEventMessage);}));
//        System.out.println("message1 = " + message);

        path = "/ParallelConsumerFail.json";
        inputLine = "parallel consumer "+path;
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof ParallelConsumerMessage);
//        ((ParallelConsumerMessage) message).getMessages().forEach((message1 -> System.out.println("message1 = " + message1)));
        ((ParallelConsumerMessage) message).getMessages().forEach((message3 -> {System.out.println("message3 = " + message3);assertTrue(message3 instanceof ErrorMessage);}));
//        System.out.println("message1 = " + message);

        inputLine ="set consumer group rebalancing g001 RoundRobin";
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof RebalancingMessage);

        inputLine ="set consumer group rebalancing g0001 RoundRobin";
        message = consumerClientCLI.func(inputLine);
        assertTrue(message instanceof ErrorMessage);


        //16
        inputLine = "playback c002 p002 0 3";
        message = consumerClientCLI.func(inputLine);
        System.out.println(message);
        assertTrue(message instanceof ConsumerEventsMessage);

        // 17
        inputLine = "playback c002 p009 0 3";
        message = consumerClientCLI.func(inputLine);
        System.out.println(message);
        assertTrue(message instanceof ErrorMessage);
//        ((ParallelConsumerMessage) message).getMessages().forEach((message1 -> System.out.println("message1 = " + message1)));
//        System.out.println("message1 = " + message);

        inputLine = "playback c004 p001 0 3";
        message = consumerClientCLI.func(inputLine);
        System.out.println(message);
        assertTrue(message instanceof ErrorMessage);
    }
}
