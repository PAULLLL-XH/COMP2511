Pair Blog
https://unswcse.atlassian.net/wiki/spaces/~63142bc3b433b060db564918/blog/edit-v2/56034434?draftShareId=c5f7ac8d-6deb-43e0-9041-1bed5f622cd8
Video blog
https://unswcse.atlassian.net/wiki/spaces/~63142bc3b433b060db564918/blog/edit-v2/55943842?draftShareId=fee7a6ef-b794-43c1-9716-25db9a81b937
