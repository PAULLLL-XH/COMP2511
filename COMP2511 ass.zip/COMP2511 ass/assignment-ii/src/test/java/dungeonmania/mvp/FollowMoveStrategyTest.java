package dungeonmania.mvp;

import dungeonmania.DungeonManiaController;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.response.models.EntityResponse;
import dungeonmania.util.Direction;
import dungeonmania.util.Position;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.awt.*;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class FollowMoveStrategyTest {
    @Test
    @Tag("15-1")
    @DisplayName("Test Allies will follow the player")
    public void willMoveFollowPlay() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_mercenaryTest_allyBattle", "c_mercenaryTest_allyBattle");

        String mercId =TestUtils.getEntitiesStream(res, "mercenary").findFirst().get().getId();

        // pick up treasure
        res = dmc.tick(Direction.RIGHT);

        // achieve bribe
        res = assertDoesNotThrow(() -> dmc.interact(mercId));


        // walk to right, mercenary will follow the player
        Position prePosition = TestUtils.getPlayer(res).get().getPosition();
        res = dmc.tick(Direction.RIGHT);

        assertEquals(prePosition,TestUtils.getEntitiesStream(res, "mercenary").findFirst().get().getPosition());

        // walk to up, mercenary will follow the player
        prePosition = TestUtils.getPlayer(res).get().getPosition();
        res = dmc.tick(Direction.UP);

        assertEquals(prePosition,TestUtils.getEntitiesStream(res, "mercenary").findFirst().get().getPosition());

    }
}
