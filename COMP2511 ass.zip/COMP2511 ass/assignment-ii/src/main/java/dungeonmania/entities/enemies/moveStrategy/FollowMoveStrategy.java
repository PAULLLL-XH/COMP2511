package dungeonmania.entities.enemies.moveStrategy;

import dungeonmania.Game;
import dungeonmania.entities.Entity;
//import dungeonmania.map.GameMap;
import dungeonmania.util.Position;

//import java.util.List;
//import java.util.Random;
//import java.util.stream.Collectors;

/**
 * Allies follow the player, and once it reaches the square adjacent to
 * the player it occupies the square the player was previously in.
 */
public class FollowMoveStrategy implements MoveStrategy {

    private final Position position;
    private final Entity entity;
    public FollowMoveStrategy(Position position, Entity entity) {
        this.position = position;
        this.entity = entity;
    }
    @Override
    public Position active(Game game) {
        return game.getPlayer().getPreviousDistinctPosition();
    }
}
