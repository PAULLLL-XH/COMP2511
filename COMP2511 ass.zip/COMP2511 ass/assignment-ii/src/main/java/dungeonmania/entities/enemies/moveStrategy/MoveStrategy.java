package dungeonmania.entities.enemies.moveStrategy;

import dungeonmania.Game;
import dungeonmania.util.Position;

public interface MoveStrategy {
    public Position active(Game game);
}
