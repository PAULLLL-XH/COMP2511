package dungeonmania.entities.enemies.moveStrategy;

import dungeonmania.Game;
import dungeonmania.entities.Boulder;
import dungeonmania.entities.Entity;
import dungeonmania.util.Position;

import java.util.List;

public class SpiderMoveStrategy implements MoveStrategy {

    private final List<Position> movementTrajectory;
    private int nextPositionElement;
    private boolean forward;
    private final Entity entity;
    public SpiderMoveStrategy(Position position, Entity entity) {
        movementTrajectory = position.getAdjacentPositions();
        nextPositionElement = 1;
        forward = true;
        this.entity = entity;
    }

    @Override
    public Position active(Game game) {
        Position nextPos = movementTrajectory.get(nextPositionElement);
        List<Entity> entities = game.getMap().getEntities(nextPos);
        if (entities != null && entities.size() > 0 && entities.stream().anyMatch(e -> e instanceof Boulder)) {
            forward = !forward;
            updateNextPosition();
            updateNextPosition();
        }
        nextPos = movementTrajectory.get(nextPositionElement);
        entities = game.getMap().getEntities(nextPos);
        if (entities == null
                || entities.size() == 0
                || entities.stream().allMatch(e -> e.canMoveOnto(game.getMap(), entity))) {
            game.getMap().moveTo(entity, nextPos);
            updateNextPosition();
        }
        return nextPos;
    }
    private void updateNextPosition() {
        if (forward) {
            nextPositionElement++;
            if (nextPositionElement == 8) {
                nextPositionElement = 0;
            }
        } else {
            nextPositionElement--;
            if (nextPositionElement == -1) {
                nextPositionElement = 7;
            }
        }
    }
}
