package dungeonmania.entities.enemies;

//import java.util.List;
//import java.util.Random;
//import java.util.stream.Collectors;

import dungeonmania.Game;
import dungeonmania.entities.Entity;
import dungeonmania.entities.Portal;
import dungeonmania.entities.enemies.moveStrategy.RandMoveStrategy;
import dungeonmania.map.GameMap;
import dungeonmania.util.Position;

public class ZombieToast extends Enemy {
    public static final double DEFAULT_HEALTH = 5.0;
    public static final double DEFAULT_ATTACK = 6.0;

    public ZombieToast(Position position, double health, double attack) {
        super(position, health, attack);
        moveStrategy = new RandMoveStrategy(position, this);
    }

    @Override
    public void move(Game game) {
        moveStrategy.active(game);
    }

    @Override
    public void onOverlap(GameMap map, Entity entity) {
        super.onOverlap(map, entity);
        if (entity instanceof Portal) {
            Portal portal = (Portal) entity;
            if (portal.getPair() == null) {
                return;
            }
            portal.doTeleport(map, this);
        }
    }
}
