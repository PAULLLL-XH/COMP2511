package dungeonmania.entities.enemies.moveStrategy;

import dungeonmania.Game;
import dungeonmania.entities.Entity;
import dungeonmania.map.GameMap;
import dungeonmania.util.Position;

public class DijkstraMoveStrategy implements MoveStrategy {
    private final Position position;
    private final Entity entity;
    public DijkstraMoveStrategy(Position position, Entity entity) {
        this.position = position;
        this.entity = entity;
    }
    @Override
    public Position active(Game game) {
        GameMap map = game.getMap();
        Position nextPos = map.dijkstraPathFind(position, map.getPlayer().getPosition(), entity);
//        map.moveTo(entity,nextPos);
        return nextPos;
    }
}
