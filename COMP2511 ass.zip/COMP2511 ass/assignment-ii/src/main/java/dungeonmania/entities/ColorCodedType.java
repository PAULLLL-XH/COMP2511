package dungeonmania.entities;

public enum ColorCodedType {
    RED,
    BLUE,
    YELLOW,
    GREEN,
    GREY;
}
