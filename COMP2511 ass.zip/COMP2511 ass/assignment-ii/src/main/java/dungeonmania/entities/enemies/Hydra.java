package dungeonmania.entities.enemies;

import dungeonmania.Game;
import dungeonmania.entities.Entity;
import dungeonmania.entities.Portal;
import dungeonmania.entities.enemies.moveStrategy.RandMoveStrategy;
import dungeonmania.map.GameMap;
import dungeonmania.util.Position;

//import java.util.Random;

public class Hydra extends Enemy {
    public static final double DEFAULT_HEALTH = 5.0;
    public static final double DEFAULT_ATTACK = 6.0;

    public Hydra(Position position, double health, double attack) {
        super(position, health, attack);
        moveStrategy = new RandMoveStrategy(position, this);
        super.setIncreaseProbability(50); //
    }

    @Override
    public void move(Game game) {
        moveStrategy.active(game);
    }

    @Override
    public void onOverlap(GameMap map, Entity entity) {
        super.onOverlap(map, entity);
        if (entity instanceof Portal) {
            Portal portal = (Portal) entity;
            if (portal.getPair() == null) {
                return;
            }
            portal.doTeleport(map, this);
        }
    }
}
