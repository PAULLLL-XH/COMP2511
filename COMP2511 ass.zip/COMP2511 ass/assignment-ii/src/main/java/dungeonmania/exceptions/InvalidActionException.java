package dungeonmania.exceptions;

public class InvalidActionException extends Exception {
    public InvalidActionException(String message) {
        super(message);
    }
}
