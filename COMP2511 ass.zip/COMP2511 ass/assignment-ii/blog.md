Pair Blog
https://unswcse.atlassian.net/wiki/spaces/~63142bc3b433b060db564918/blog/2022/11/03/49250637/PAIR+BLOG+-+ASSIGNMENT+2

Personal Blog:
Xuanhao Mei:
https://unswcse.atlassian.net/wiki/spaces/~63142bc3b433b060db564918/blog/2022/11/06/49823143/Personal+Blog+-+Assignment+-+Task+1+-+e+-+Xuanhao+Mei
https://unswcse.atlassian.net/wiki/spaces/~63142bc3b433b060db564918/blog/2022/11/06/49725387/Personal+Blog+-+Assignment+-+Task+1+-+f+-+Xuanhao+Mei
https://unswcse.atlassian.net/wiki/spaces/~63142bc3b433b060db564918/blog/2022/11/06/49693243/Personal+Blog+-+Assignment+-+Task+1+-+h+-+Xuanhao+Mei
https://unswcse.atlassian.net/wiki/spaces/~63142bc3b433b060db564918/blog/2022/11/06/49823389/Personal+Blog+-+Assignment+-+Task+1+-+g+-+Xuanhao+Mei

Chenxu Zhu:
