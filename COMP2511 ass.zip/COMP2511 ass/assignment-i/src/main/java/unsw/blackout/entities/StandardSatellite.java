package unsw.blackout.entities;

import unsw.utils.Angle;

public class StandardSatellite extends Satellite {


    private static final int VX = 2500;


    public StandardSatellite(String satelliteId, double height, Angle position) {
        super(satelliteId, "StandardSatellite", height, position);
        setMaxRange(150000);
    }

    @Override
    public int getSpeed() {
        return 1;
    }

    @Override
    public void simulate() {

        // file
        int speed = 1;
        for (File file : this.getFiles()) {
            if (!file.getInfo().hasTransferCompleted()) {
                file.transfer(speed);
            }
        }

        double delta = VX / this.getHeight();
        double degree = Angle.fromRadians(delta).toDegrees();
        this.setPosition(this.getPosition().subtract(Angle.fromRadians(delta)));
        if (this.getPosition().toDegrees() > 0) {
            while (this.getPosition().toDegrees() > 360) {
                this.setPosition(this.getPosition().subtract(Angle.fromDegrees(360)));
            }
        } else {
            while (this.getPosition().toDegrees() < 0) {
                this.setPosition(this.getPosition().add(Angle.fromDegrees(360)));
            }
        }
    }
}
