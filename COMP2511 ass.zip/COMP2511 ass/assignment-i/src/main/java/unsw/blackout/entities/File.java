package unsw.blackout.entities;

import unsw.response.models.FileInfoResponse;

public final class File {
    private final String filename;
    private final String content;

    private boolean hasTransferCompleted;

    private int transferByte;

    public File(String filename, String content) {
        this.filename = filename;
        this.content = content;
        this.hasTransferCompleted = true;
    }

    public File(String filename, String content, boolean hasTransferCompleted) {
        this.filename = filename;
        this.content = content;
        this.hasTransferCompleted = hasTransferCompleted;
        transferByte = 0;
    }

    public String getFilename() {
        return filename;
    }

    public String getContent() {
        return content;
    }

    public FileInfoResponse getInfo() {
        if (!hasTransferCompleted)
            return new FileInfoResponse(filename, content.substring(0, transferByte),  content.length(), false);
        return new FileInfoResponse(filename, content, content.length(), true);
    }

    public boolean getHasTransferCompleted() {
        return this.hasTransferCompleted;
    }
    public void transfer(int speed) {
        this.transferByte += speed;
        if (this.transferByte >= content.length()) {
            hasTransferCompleted = true;
        }
    }
}
