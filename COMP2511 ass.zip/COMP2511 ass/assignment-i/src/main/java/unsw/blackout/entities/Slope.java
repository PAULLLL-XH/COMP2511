package unsw.blackout.entities;

public class Slope {

    private final int startAngle;
    private final int endAngle;
    private final int gradient;


    public Slope(int startAngle, int endAngle, int gradient) {
        this.startAngle = startAngle;
        this.endAngle = endAngle;
        this.gradient = gradient;
    }

    public int getStartAngle() {
        return startAngle;
    }

    public int getEndAngle() {
        return endAngle;
    }

    public int getGradient() {
        return gradient;
    }
}
