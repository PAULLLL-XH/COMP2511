package unsw.blackout;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import unsw.blackout.entities.*;
import unsw.response.models.EntityInfoResponse;
import unsw.response.models.FileInfoResponse;
import unsw.utils.Angle;

//import java.util.ArrayList;
//import java.util.List;
//
//import unsw.response.models.EntityInfoResponse;
//import unsw.utils.Angle;

public class BlackoutController {
    private final ArrayList<Device> devices;
    private final ArrayList<Satellite> satellites;

    private final ArrayList<Slope> slopes;

    public BlackoutController() {
        this.devices = new ArrayList<>();
        this.satellites = new ArrayList<>();
        this.slopes = new ArrayList<>();
    }

    public void createDevice(String deviceId, String type, Angle position) {
        // TODO: Task 1a)
        switch (type) {
            case "HandheldDevice":
                devices.add(new HandheldDevice(deviceId, position));
                break;
            case "LaptopDevice":
                devices.add(new LaptopDevice(deviceId, position));
                break;
            case "DesktopDevice":
                devices.add(new DesktopDevice(deviceId, position));
                break;
            default:
                break;
        }
    }

    public void removeDevice(String deviceId) {
        // TODO: Task 1b)
        for (Device device : devices) {
            if (device.getDeviceId().equals(deviceId)) {
                this.devices.remove(device);
                break;
            }
        }
    }

    public void createSatellite(String satelliteId, String type, double height, Angle position) {
        // TODO: Task 1c)
        switch (type) {
            case "StandardSatellite":
                this.satellites.add(new StandardSatellite(satelliteId, height, position));
                break;
            case "TeleportingSatellite":
                this.satellites.add(new TeleportingSatellite(satelliteId, height, position));
                break;
            case "RelaySatellite":
                this.satellites.add(new RelaySatellite(satelliteId, height, position));
                break;
            default:
                break;

        }
    }

    public void removeSatellite(String satelliteId) {
        // TODO: Task 1d)
        for (Satellite satellite : satellites) {
            if (satellite.getSatelliteId().equals(satelliteId)) {
                satellites.remove(satellite);
                break;
            }
        }
    }

    public List<String> listDeviceIds() {
        // TODO: Task 1e)
        List<String> result = new ArrayList<>();
        for (Device device : devices) {
            result.add(device.getDeviceId());
        }
        return result;
    }

    public List<String> listSatelliteIds() {
        // TODO: Task 1f)
        List<String> result = new ArrayList<>();
        for (Satellite satellite : satellites) {
            result.add(satellite.getSatelliteId());
        }
        return result;
    }

    public void addFileToDevice(String deviceId, String filename, String content) {
        // TODO: Task 1g)
        for (Device device : devices) {
            if (device.getDeviceId().equals(deviceId)) {
                device.addFile(filename, content);
            }
        }
    }

    public EntityInfoResponse getInfo(String id) {
        // TODO: Task 1h)
        for (Device device : devices) {
            if (device.getDeviceId().equals(id)) {
                return device.getInfo();
            }
        }
        for (Satellite satellite : satellites) {
            if (satellite.getSatelliteId().equals(id)) {
                return satellite.getInfo();
            }
        }
        return null;
    }

    public void simulate() {
        // TODO: Task 2a)
        for (Device device : devices) {
            device.simulate(satellites);
        }
        for (Satellite satellite : satellites) {
            satellite.simulate();
        }
    }

    /**
     * Simulate for the specified number of minutes.
     * You shouldn't need to modify this function.
     */
    public void simulate(int numberOfMinutes) {
        for (int i = 0; i < numberOfMinutes; i++) {
            simulate();
        }
    }

    public List<String> communicableEntitiesInRange(String id) {
        // TODO: Task 2 b)
        for (Satellite srcSatellite : satellites) {
            if (srcSatellite.getSatelliteId().equals(id)) {
                List<String> res = new ArrayList<>();
                ArrayList<Satellite> satelliteArrayList = new ArrayList<>();

                ArrayList<Satellite> connectSet = new ArrayList<>();
                connectSet.add(srcSatellite);
                ArrayList<Device> deviceArrayList = new ArrayList<>();

                for (Satellite dstSatellite : satellites) {
                    if (dstSatellite.equals(srcSatellite))
                        continue;
                    for (Satellite relaySatellite : connectSet) {
                        if (relaySatellite.isVisible(dstSatellite)) {
                            satelliteArrayList.add(dstSatellite);
                            if (dstSatellite.getType().equals("RelaySatellite")) {
                                connectSet.add(dstSatellite);
                            }
                        }
                    }
                }

                for (Device device : devices) {
                    if (srcSatellite.getType().equals("StandardSatellite") && device.getType().equals("DesktopDevice"))
                        continue;
                    for (Satellite relaySatellite : connectSet) {
                        if (relaySatellite.isVisible(device)) {
                            deviceArrayList.add(device);
                        }
                    }
                }

                for (Satellite satellite : satelliteArrayList) {
                    res.add(satellite.getSatelliteId());
                }
                for (Device device : deviceArrayList) {
                    res.add(device.getDeviceId());
                }
                return res;
            }
        }
        for (Device srcDevice : devices) {
            if (srcDevice.getDeviceId().equals(id)) {
                List<String> res = new ArrayList<>();

                for (Satellite satellite : satellites) {
//                    List<String> set = communicableEntitiesInRange(satellite.getSatelliteId());
//                    // judge this satellite if or not connect to this device
//                    boolean flag = false;
//                    for(String s : set){
//                        if (s.equals(id)) {
//                            flag = true;
//                            break;
//                        }
//                    }
//                    if(flag){
//                        set.add(satellite.getSatelliteId());
//                        for(String s : set){
//                            // judge if or not already in
//                            flag = false;
//                            for(String s1 : res){
//                                if(s1.equals(s)){
//                                    flag = true;
//                                    break;
//                                }
//                            }
//                            if(!flag){
//                                res.add(s);
//                            }
//                        }
//                    }
                    if (satellite.isVisible(srcDevice)) {
                        res.add(satellite.getSatelliteId());
                    }
                }

                return res;
            }

        }
        return new ArrayList<>();
    }

    public void sendFile(String fileName, String fromId, String toId) throws FileTransferException {
        // TODO: Task 2 c)
        for (Satellite satellite : satellites) {
            if (satellite.getSatelliteId().equals(fromId)) {
                // from a satellite
                Map<String, FileInfoResponse> files = satellite.getInfo().getFiles();
                FileInfoResponse fileInfoResponse = files.get(fileName);
                if (fileInfoResponse != null) {
                    if (!fileInfoResponse.hasTransferCompleted()) {
                        throw new FileTransferException.VirtualFileNotFoundException(fileName);
                    }
                } else {
                    throw new FileTransferException.VirtualFileNotFoundException(fileName);
                }

                // to satellite
                for (Satellite target : satellites) {
                    if (target.getSatelliteId().equals(toId)) {
                        if (target.getInfo().getFiles().containsKey(fileName)) {
                            throw new FileTransferException.VirtualFileAlreadyExistsException(fileName);
                        }

                        target.addFile(fileInfoResponse);

                    }
                }

                // to device
                for (Device target : devices) {
                    if (target.getDeviceId().equals(toId)) {
                        if (target.getInfo().getFiles().containsKey(fileName)) {
                            throw new FileTransferException.VirtualFileAlreadyExistsException(fileName);
                        }
                        target.addFile(fileInfoResponse);
                    }
                }

            }
        }
        for (Device device : devices) {
            if (device.getDeviceId().equals(fromId)) {
                // from a device
                Map<String, FileInfoResponse> files = device.getInfo().getFiles();
                FileInfoResponse fileInfoResponse = files.get(fileName);
                if (files.containsKey(fileName)) {
                    if (!fileInfoResponse.hasTransferCompleted()) {
                        throw new FileTransferException.VirtualFileNotFoundException(fileName);
                    }
                } else {
                    throw new FileTransferException.VirtualFileNotFoundException(fileName);
                }

                // to satellite
                for (Satellite target : satellites) {
                    if (target.getSatelliteId().equals(toId)) {
                        if (target.getInfo().getFiles().containsKey(fileName)) {
                            throw new FileTransferException.VirtualFileAlreadyExistsException(fileName);
                        }

                        target.addFile(fileInfoResponse);

                    }
                }


            }
        }
    }

    public void createDevice(String deviceId, String type, Angle position, boolean isMoving) {
        createDevice(deviceId, type, position);
        // TODO: Task 3
        switch (type) {
            case "HandheldDevice":
                devices.add(new HandheldDevice(deviceId, position, isMoving));
                break;
            case "LaptopDevice":
                devices.add(new LaptopDevice(deviceId, position, isMoving));
                break;
            case "DesktopDevice":
                devices.add(new DesktopDevice(deviceId, position, isMoving));
                break;
            default:
                break;
        }
    }

    public void createSlope(int startAngle, int endAngle, int gradient) {
        // TODO: Task 3
        // If you are not completing Task 3 you can leave this method blank :)
        slopes.add(new Slope(startAngle, endAngle, gradient));
    }

}
