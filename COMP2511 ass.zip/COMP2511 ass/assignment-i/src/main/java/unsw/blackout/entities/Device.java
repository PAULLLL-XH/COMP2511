package unsw.blackout.entities;

import unsw.response.models.EntityInfoResponse;
import unsw.response.models.FileInfoResponse;
import unsw.utils.Angle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static unsw.utils.MathsHelper.RADIUS_OF_JUPITER;

public class Device {
    private final String deviceId;
    private final String type;
    private Angle position;
    private final ArrayList<File> files;

    private int movingSpeed;

    private final boolean isMoving;
    private boolean onSlope;

    Device(String deviceId, String type, Angle position) {
        this.deviceId = deviceId;
        this.type = type;
        this.position = position;
        this.isMoving = false;
        onSlope = false;
        this.files = new ArrayList<>();
    }
    Device(String deviceId, String type, Angle position, boolean isMoving) {
        this.deviceId = deviceId;
        this.type = type;
        this.position = position;
        this.isMoving = isMoving;
        this.files = new ArrayList<>();
    }

    public Angle getPosition() {
        return position;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public String getType() {
        return type;
    }

    public void addFile(String filename, String content) {
        this.files.add(new File(filename, content));
    }

    public void addFile(FileInfoResponse file) {
        this.files.add(new File(file.getFilename(), file.getData(), false));
    }

    public EntityInfoResponse getInfo() {
        Map<String, FileInfoResponse> fileInfoResponseMap = new HashMap<>();
        for (File file : files) {
            fileInfoResponseMap.put(file.getFilename(), file.getInfo());
        }
        return new EntityInfoResponse(this.deviceId, position, RADIUS_OF_JUPITER, this.type, fileInfoResponseMap);
    }

    public void fileTransfer(int speed) {

    }

    public void simulate(ArrayList<Satellite> satellites) {
        // file
        for (File file : files) {
            if (!file.getHasTransferCompleted()) {
                for (Satellite satellite : satellites) {
                    FileInfoResponse fileInfoResponse = satellite.getInfo().getFiles().get(file.getFilename());
                    if (fileInfoResponse != null) {
                        int speed = satellite.getSpeed();
                        file.transfer(speed);
                    }
                }
            }
        }
        // moving
        if (isMoving) {
            if (!onSlope) {
                double delta = movingSpeed / RADIUS_OF_JUPITER;
                this.position = this.position.subtract(Angle.fromRadians(delta));
                if (this.position.toDegrees() > 0) {
                    while (this.position.toDegrees() > 360) {
                        this.position = this.position.subtract(Angle.fromDegrees(360));
                    }
                } else {
                    while (this.position.toDegrees() < 0) {
                        this.position = this.position.add(Angle.fromDegrees(360));
                    }
                }

            }
        }
    }

    public void setMovingSpeed(int movingSpeed) {
        this.movingSpeed = movingSpeed;
    }
}
