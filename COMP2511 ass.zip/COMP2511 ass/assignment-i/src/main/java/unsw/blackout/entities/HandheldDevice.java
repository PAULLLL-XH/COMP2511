package unsw.blackout.entities;

import unsw.utils.Angle;

public class HandheldDevice extends Device {

    public HandheldDevice(String deviceId, Angle position) {
        super(deviceId, "HandheldDevice", position);
    }

    public HandheldDevice(String deviceId, Angle position, boolean isMoving) {
        super(deviceId, "HandheldDevice", position, isMoving);
        setMovingSpeed(50);
    }
}
