package unsw.blackout.entities;

import unsw.utils.Angle;

public class LaptopDevice extends Device {
    public LaptopDevice(String deviceId, Angle position) {
        super(deviceId, "LaptopDevice", position);
    }

    public LaptopDevice(String deviceId, Angle position, boolean isMoving) {
        super(deviceId, "LaptopDevice", position, isMoving);
        setMovingSpeed(30);
    }
}
