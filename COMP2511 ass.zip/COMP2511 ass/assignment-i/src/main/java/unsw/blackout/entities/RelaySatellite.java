package unsw.blackout.entities;

import unsw.utils.Angle;

public class RelaySatellite extends Satellite {

    private static final int VX = 1500;

    public RelaySatellite(String satelliteId, double height, Angle position) {
        super(satelliteId, "RelaySatellite", height, position);
        setMaxRange(300000);
    }


    @Override
    public void simulate() {
        double delta = VX / this.getHeight();

        // from 190 to 345
        if (190 < this.getPosition().toDegrees() && this.getPosition().toDegrees() < 345) {
            setDirection(true);
        }

        // from 345 to 140
        if (
                345 <= this.getPosition().toDegrees() && this.getPosition().toDegrees() <= 360
                        || this.getPosition().toDegrees() < 140 && this.getPosition().toDegrees() > 0
        ) {
            setDirection(false);
        }

        if (!isDirection()) {
            this.setPosition(this.getPosition().add(Angle.fromRadians(delta)));
            if (this.getPosition().toDegrees() > 360) {
                this.setPosition(this.getPosition().subtract(Angle.fromDegrees(360)));
            }
        } else {
            this.setPosition(this.getPosition().subtract(Angle.fromRadians(delta)));
        }
    }
}
