package unsw.blackout.entities;

import unsw.response.models.EntityInfoResponse;
import unsw.response.models.FileInfoResponse;
import unsw.utils.Angle;
import unsw.utils.MathsHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Satellite {

    private boolean direction = true;
    private final String satelliteId;
    private Angle position;
    private final String type;
    private final double height;

    private final ArrayList<File> files;
    private static int MAX_RANGE;

    private int fileTransferring = 0;

    Satellite(String satelliteId, String type, double height, Angle position) {
        this.satelliteId = satelliteId;
        this.type = type;
        this.height = height;
        this.position = position;
        files = new ArrayList<>();
    }

    public static void setMaxRange(int maxRange) {
        MAX_RANGE = maxRange;
    }

    public Angle getPosition() {
        return position;
    }

    public String getSatelliteId() {
        return satelliteId;
    }

    public double getHeight() {
        return height;
    }

    public String getType() {
        return type;
    }

    public EntityInfoResponse getInfo() {
        Map<String, FileInfoResponse> fileInfoResponseMap = new HashMap<>();
        for (File file : files) {
            fileInfoResponseMap.put(file.getFilename(), file.getInfo());
        }
        return new EntityInfoResponse(this.satelliteId, position, height, this.type, fileInfoResponseMap);
    }

    public int getMAX_RANGE() {
        return MAX_RANGE;
    }

    public boolean isVisible(Device device) {
        if (this.getType().equals("StandardSatellite") && device.getType().equals("DesktopDevice"))
            return false;
        return (
                // isVisible
                MathsHelper.isVisible(this.getHeight(), this.getPosition(), device.getPosition())
                        // distance
                        &&
                        MathsHelper.getDistance(this.getHeight(), this.getPosition(), device.getPosition()) < MAX_RANGE

        );
    }

    public boolean isVisible(Satellite satellite) {
        return (
                MathsHelper.isVisible(
                        this.getHeight(), this.getPosition(), satellite.getHeight(), satellite.getPosition()
                ) && MathsHelper.getDistance(this.getHeight(), this.getPosition(), satellite.getHeight(),
                        satellite.getPosition()) < MAX_RANGE
        );
    }

    public void simulate() {

    }

    public void transferFile(FileInfoResponse fileInfoResponse) {

    }

    public void addFile(FileInfoResponse file) {
        this.files.add(new File(file.getFilename(), file.getData(), false));
        fileTransferring += 1;
    }

    public int getSpeed() {
        return 0;
    }

    public void setDirection(boolean direction) {
        this.direction = direction;
    }

    public boolean isDirection() {
        return direction;
    }

    public void setPosition(Angle position) {
        this.position = position;
    }

    public ArrayList<File> getFiles() {
        return files;
    }
}
