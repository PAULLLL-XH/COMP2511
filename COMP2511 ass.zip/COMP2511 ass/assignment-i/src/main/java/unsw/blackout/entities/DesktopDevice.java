package unsw.blackout.entities;

import unsw.utils.Angle;

public class DesktopDevice extends Device {


    public DesktopDevice(String deviceId, Angle position) {
        super(deviceId, "DesktopDevice", position);
    }

    public DesktopDevice(String deviceId, Angle position, boolean isMoving) {
        super(deviceId, "DesktopDevice", position, isMoving);
        setMovingSpeed(20);
    }


}
