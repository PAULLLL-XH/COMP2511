package unsw.blackout.entities;

import unsw.utils.Angle;

public class TeleportingSatellite extends Satellite {

    private static final int VX = 1000;


    public TeleportingSatellite(String satelliteId, double height, Angle position) {
        super(satelliteId, "TeleportingSatellite", height, position);
        setMaxRange(20000);
        setDirection(false);
    }

    @Override
    public void simulate() {
        double delta = VX / this.getHeight();
        if (this.isDirection()) {
            if (this.getPosition().toDegrees() > 180
                    && this.getPosition().subtract(Angle.fromRadians(delta)).toDegrees() < 180) {
                this.setPosition(Angle.fromDegrees(0));
                this.setDirection(false);
            } else {
                this.setPosition(this.getPosition().subtract(Angle.fromRadians(delta)));
            }
        } else {
            if (this.getPosition().toDegrees() < 180
                    && this.getPosition().add(Angle.fromRadians(delta)).toDegrees() > 180) {
                this.setPosition(Angle.fromDegrees(0));
                this.setDirection(true);
            } else {
                this.setPosition(this.getPosition().add(Angle.fromRadians(delta)));
            }

        }
    }
}
