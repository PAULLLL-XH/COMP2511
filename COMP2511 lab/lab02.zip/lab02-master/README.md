You can find the specification for this lab here:

https://unswcse.atlassian.net/wiki/spaces/cs2511/pages/27328520/Lab+02
