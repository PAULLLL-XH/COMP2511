package staff;

import java.time.LocalDate;

/**
 * A staff member
 * @author Robert Clifton-Everest
 *
 */
public class StaffMember {
    // StaffMember
    private String name;
    private float salary;
    private LocalDate hireDate;
    private LocalDate endDate;

    // Constructor
    /**
     * Constructor for StaffMember
     * @param name
     * @param salary
     * @param hireDate
     * @param endDate
     */
    public StaffMember(String name, float salary, LocalDate hireDate, LocalDate endDate) {
        this.name = name;
        this.salary = salary;
        this.hireDate = hireDate;
        this.endDate = endDate;
    }

    /**
     * Getter for name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Getter for salary
     */
    public float getSalary() {
        return this.salary;
    }

    /**
     * Getter for hiredate
     */
    public LocalDate getHireDate() {
        return this.hireDate;
    }

    /**
     * Getter for enddate
     */
    public LocalDate getEndDate() {
        return this.endDate;
    }

    /**
     * Setter for name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Setter for salary
     */
    public void setSalary(float salary) {
        this.salary = salary;
    }

    /**
     * Setter for hiredate
     */
    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }

    /**
     * Setter for enddate
     */
    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    /**
     * Override toString method
     * return the detail of the StaffMember
     */
    @Override
    public String toString() {
        String s = "name: " + this.getName() + "; salary: " + this.getSalary() + "; hireDate: " + this.getHireDate() + "; endDate: " + this.getEndDate();
        return s;
    }

    /**
     * Override equals method
     */
    @Override
    public boolean equals(Object o) {

        if (o == null) {
            return false;
        }

        if (this.getClass() != o.getClass()) {
            return false;
        }

        StaffMember other = (StaffMember) o;

        if (other.getName() == this.name && other.getSalary() == this.salary && other.getHireDate().equals(this.hireDate) && other.getEndDate().equals(this.endDate)) {
            return true;
        } else {
            return false;
        }

    }
}
