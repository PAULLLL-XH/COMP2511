package staff;

import java.time.LocalDate;

public class Lecturer extends StaffMember {

    private String schoolName;
    private String academicStatus;

    /**
     * Constructor for Lecturer
     * @param name
     * @param salary
     * @param hireDate
     * @param endDate
     * @param schoolName
     * @param academicStatus
     */
    public Lecturer(String name, float salary, LocalDate hireDate, LocalDate endDate, String schoolName, String academicStatus) {
        super(name, salary, hireDate, endDate);
        this.schoolName = schoolName;
        this.academicStatus = academicStatus;
    }

    /**
     * Getter for schoolName
     */
    public String getSchoolName() {
        return this.schoolName;
    }

    /**
     * Getter for academicStatus
     */
    public String getAcademicStatus() {
        return this.academicStatus;
    }

    /**
     * Setter for schoolName
     */
    public void setSchool(String schoolName) {
        this.schoolName = schoolName;
    }

    /**
     * Setter for academicStatus
     */
    public void setAcademicStatus(String academicStatus) {
        this.academicStatus = academicStatus;
    }

    /**
     * Override toString
     * return the detail of the Lecturer
     */
    @Override
    public String toString() {
        String s = "name: " + this.getName() + "; salary: " + this.getSalary() + "; hireDate: " + this.getHireDate() + "; endDate: " + this.getEndDate() + "; schoolName: " + this.getSchoolName() + "; academicStatus: " + this.getAcademicStatus();
        return s;
    }

    /**
     * Override equals
     */
    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }

        if (this.getClass() != o.getClass()) {
            return false;
        }

        Lecturer other = (Lecturer) o;

        if (other.getName() == this.getName() && other.getSalary() == this.getSalary() && other.getHireDate().equals(this.getHireDate()) && other.getEndDate().equals(this.getEndDate()) && other.getAcademicStatus() == this.academicStatus && this.schoolName == other.getSchoolName()) {
            return true;
        }
        else {
            return false;
        }
    }
}
