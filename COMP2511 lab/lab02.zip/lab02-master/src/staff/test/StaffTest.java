package staff.test;

import java.time.LocalDate;
import staff.StaffMember;
import staff.Lecturer;

public class StaffTest {

    public void printStaffDetails(StaffMember A) {
        System.out.println(A.toString());
    }

    public static void main(String[] args) {
        StaffMember Pan = new StaffMember("Pan", 10000, LocalDate.of(2022,9,24), LocalDate.of(2022,9,25));
        Lecturer Yan = new Lecturer("Yan", 10000, LocalDate.of(2022,9,24), LocalDate.of(2022,9,25), "unsw", "A");
        StaffMember Mei = new StaffMember("Mei", 10000, LocalDate.of(2022,9,24), LocalDate.of(2022,9,25));
        StaffTest test  = new StaffTest();
        test.printStaffDetails(Pan);
        test.printStaffDetails(Yan);
        System.out.println("test equal result: " + Mei.equals(Pan));
    }
}
