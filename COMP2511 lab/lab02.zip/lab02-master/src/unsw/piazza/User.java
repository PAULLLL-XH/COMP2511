package unsw.piazza;

/**
 * A user of the Piazza forum
 */
public class User { 

    /**
     * Creates a new user with the given name.
     * @param name
     */
    public User(String name) {}

    public String getName() {
        return null;
    }

    /**
     * Sets the user's name to the given name
     * @param name
     */
    public void setName(String name) {}
}
