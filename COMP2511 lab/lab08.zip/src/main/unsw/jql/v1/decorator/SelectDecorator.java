package unsw.jql.v1.decorator;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import unsw.jql.v1.SimpleTableView;
import unsw.jql.v1.TableView;


public class SelectDecorator<E, R> extends OperationDecorator<R>  {
    private Function<E, R> selector;
    private TableView<E> inner;
    /**
     * Map a table view to another table view.
     * 
     * Each item/record is mapped through the provided selector.
     * 
     * An example would be `new SelectDecorator(view, (fruit) -> fruit.age()))`
    */
    public SelectDecorator(TableView<E> inner, Function<E, R> selector){
        super(null);
        this.inner = inner;
        this.selector = selector; 
    }

    @Override
    public boolean hasNext() {
        return inner.hasNext();
    }

    @Override
    public R next() {
        E item = inner.next();
        return selector.apply(item);
    }

    
    @Override
    public int count() {
        return inner.count();
    }
}

