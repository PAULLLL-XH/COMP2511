package banking;

public class BankAccount {
    
    private double balance;

    public BankAccount(double balance) {
        this.balance = balance;
    }

    public void setBalance(double amount) {
        this.balance = amount;
    }

    public double getBalance() {
        return balance;
    }

    /**
     * @pre amount >= 0
     */
    public void deposit(double amount) throws DeniedOperationException {
        // 存入的金额必须为正
        if (amount < 0) {
            throw new DeniedOperationException("Invalid input");
        }
        else {
            balance += amount;
        }
    } 

    /**
     * @pre balance >= amount
     * @post balance >= 0
     */
    public void withdrawals(double amount) throws DeniedOperationException {
        // 当账号上有足够的金额时才能允许支出操作
        if (amount > balance) {
            throw new DeniedOperationException("Amount not avaliable!");
        }
        else {
            balance -= amount;
        }
    }
}