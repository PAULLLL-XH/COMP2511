package banking;

import java.util.ArrayList;
import java.util.List;

public class LoggedBankAccount extends BankAccount{
    
    private List<String> logMessage;
    
    public LoggedBankAccount(double balance) {
        super(balance);
        this.logMessage = new ArrayList<String>();
    }

    @Override
    public void deposit(double amount) throws DeniedOperationException {
        // 存入的金额必须为正
        if (amount < 0) {
            throw new DeniedOperationException("Invalid input");
        }
        else {
            this.setBalance(amount+getBalance());
            logMessage.add("Deposit " + amount + " successfully!");
        }
    }

    public void withdrawals(double amount) throws DeniedOperationException {
        // 当账号上有足够的金额时才能允许支出操作
        if (amount > this.getBalance()) {
            throw new DeniedOperationException("Amount not avaliable!");
        }
        else {
            this.setBalance(this.getBalance()-amount);
            logMessage.add("withdrawals " + amount + " successfully!");
        }
    }
}
