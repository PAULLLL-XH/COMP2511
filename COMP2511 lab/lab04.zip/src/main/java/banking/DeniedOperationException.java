package banking;

public class DeniedOperationException extends Exception{
    public DeniedOperationException(String message) {
        super(message);
    }
}