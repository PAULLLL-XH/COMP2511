package unsw.enrolment;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * A course in the enrolment system.
 * @author Robert Clifton-Everest & Nick Patrikeos
 *
 */
public class Course {

    private String courseCode;
    private String title;
    private List<Course> prereqs = new ArrayList<Course>();
    private List<CourseOffering> courseOfferings = new ArrayList<CourseOffering>();

    public Course(String courseCode, String title) {
        this.courseCode = courseCode;
        this.title = title;
    }

    public void addPrereq(Course course) {
        prereqs.add(course);
    }

    public void addOffering(CourseOffering offering) {
        courseOfferings.add(offering);
    }

    public String getCourseCode() {
        return courseCode;
    }

    public List<Course> getPrereqs() {
        return prereqs;
    }

    public String getTitle() {
        return title;
    }

    public boolean checkValidEnrolment(Student student) {

        Stream<Course> prereqList = prereqs.stream();
        int size = (int) prereqList.filter(prereq -> student.hasValidPrereqEnrolment(prereq)).count();

        if (size != prereqs.size()) {
            return false;
        }
        // for (Course prereq : prereqs) {
        //     // List<Enrolment> studentEnrolments = student.getEnrolments();
        //     // boolean valid = false;
        //     // for (Enrolment enrolment : studentEnrolments) {
        //     //     // if (enrolment.getCourse().equals(prereq) && enrolment.getGrade() != null) {
        //     //     //     if (enrolment.getGrade().getMark() >= 50 && enrolment.getGrade().getGrade() != "FL"
        //     //     //         && enrolment.getGrade().getGrade() != "UF") {
        //     //     //             valid = true;
        //     //     //         }
        //     //     // }
        //     //     // if (!valid) {
        //     //     //     return false;
        //     //     // }

        //     //     if (enrolment.getCourse().equals(prereq)) {
        //     //         if (enrolment.hasPassedCourse()) {
        //     //             valid = true;
        //     //         }
        //     //     }
        //     //     if (!valid) {
        //     //         return false;
        //     //     }
        //     // }
        //     if (!student.hasValidPrereqEnrolment(prereq)) {
        //         return false;
        //     }
        // }
        return true;
    }
}
