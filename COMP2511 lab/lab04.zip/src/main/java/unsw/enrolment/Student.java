package unsw.enrolment;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Student {

    private String zid;
    private ArrayList<Enrolment> enrolments = new ArrayList<Enrolment>();
    private String name;
    private int program;
    private String[] streams;

	public Student(String zid, String name, int program, String[] streams) {
        this.zid = zid;
        this.name = name;
        this.program = program;
        this.streams = streams;
    }

    public boolean isEnrolled(CourseOffering offering) {
        Stream<Enrolment> enrolmentStream = enrolments.stream();
        if (enrolmentStream.anyMatch(enrolment -> enrolment.getOffering().equals(offering))) {
            return true;
        }
        
        // for (Enrolment enrolment : enrolments) {
        //     if (enrolment.getOffering().equals(offering)) {
        //         return true;
        //     }
        // }
        return false;
    }

    public void setGrade(Grade grade) {

        Stream<Enrolment> enrolmentStream = enrolments.stream();
        // Stream<Enrolment> enrolmentStremFilter = enrolmentStream.filter(enrolment -> enrolment.getOffering().equals(grade.getOffering()));
        // Enrolment target = enrolmentStremFilter.findFirst().get();

        Enrolment target = enrolmentStream.filter(enrolment -> enrolment.getOffering().equals(grade.getOffering())).findFirst().get();
        target.setGrade(grade);

        // for (Enrolment enrolment : enrolments) {
        //     if (enrolment.getOffering().equals(grade.getOffering())) {
        //         enrolment.setGrade(grade);
        //     }
        // }
    }

    public void addEnrolment(Enrolment enrolment) {
        enrolments.add(enrolment);
    }

    public List<Enrolment> getEnrolments() {
        return enrolments;
    }

    public boolean hasValidPrereqEnrolment(Course prereq) {
        Stream<Enrolment> enrolmentStream = enrolments.stream();
        if (enrolmentStream.anyMatch(enrolment -> enrolment.getCourse().equals(prereq) && !enrolment.hasPassedCourse())) {
            return false;
        }
        // boolean valid = false;
        // for (Enrolment enrolment : enrolments) {
        //     if (enrolment.getCourse().equals(prereq)) {
        //         if (enrolment.hasPassedCourse()) {
        //             valid = true;
        //         }
        //     }
        //     if (!valid) {
        //         return false;
        //     }
        // }
        return true;
    }

    public int getProgram() {
        return this.program;
    }

    public int getStreamNum() {
        return this.streams.length;
    }

    public String getName() {
        return this.name;
    }

}
