package unsw.sso;

import java.util.HashMap;
import java.util.Map;

import unsw.sso.providers.Hoogle;
import unsw.sso.providers.InstaHam;
import unsw.sso.providers.Checklock;

public class Provider {
    private Map<String, Boolean> usersExist = new HashMap<>();
    private Checklock providerServer= null;
    public Provider(Checklock providerServer) {
        this.providerServer = providerServer;
    }
    public Map<String, Boolean> getUsersExist() {
        return usersExist;
    }
    public void setUsersExist(Map<String, Boolean> usersExist) {
        this.usersExist = usersExist;
    }
    public Checklock getProviderServer() {
        return providerServer;
    }
    public void setProviderServer(Checklock providerServer) {
        this.providerServer = providerServer;
    }

    public boolean hasUser(String email){
        return usersExist.containsKey(email);
    }

    public void put(String name, boolean value) {
        usersExist.put(name, value);
    }

    public InstaHam getInstaHam() {
        if (this.providerServer instanceof InstaHam){
            return ((InstaHam)providerServer);
        }
        return null;
    }

    public Hoogle getHoogle() {
        if (this.providerServer instanceof Hoogle){
            return ((Hoogle)providerServer);
        }
        return null;
    }
    public boolean getOrDefault(String email, boolean b) {
        return usersExist.getOrDefault(email,b);
    }
    public boolean checkLock(String email) {
        return providerServer.checkLock(email);
    }

}
