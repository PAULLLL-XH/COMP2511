package unsw.sso;

// import java.time.LocalDateTime;
// import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import unsw.sso.pages.Home;
import unsw.sso.pages.Null;
import unsw.sso.pages.Interact;

public class Browser {
    private List<Token> cache = new ArrayList<Token>();
    private Interact currentPage = new Null();
    private ClientApp currentApp = null;

    public void visit(ClientApp app) {
        Token t = hasUserLogin(app);
        Interact home = new Home(new Null());
        this.currentApp = app;
        currentPage = home.interact(currentApp, t);
    }

    public String getCurrentPageName() {
        return this.currentPage.getContent();
    }

    public void clearCache() {
        // TODO:
        cache.clear();
    }

    public void interact(Object using) {
        if (using == null) {
            currentPage = currentPage.goBack();
            return;
        }
        Interact next = this.currentPage.interact(currentApp, using);
        if (next instanceof Home){
            registerUser((Token)using);
        }
        currentPage = next;
    }

    private void registerUser(Token t) {
        this.cache.add(t);
        this.currentApp.registerUser(t);
    }

    private Token hasUserLogin(ClientApp app) {
        for (Token t: this.cache) {
            if (app.hasUser(t.getUserEmail())) {
                return t;
            }
        }
        return null;
    }

}
