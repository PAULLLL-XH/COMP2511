package unsw.sso.providers;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import unsw.sso.Browser;

public class User {
    private String email = null;
    private String password = null;
    private Set<String> codes = null;
    private Browser browser = null;
    private int failedTimes = 0;

    public User(String email, String password) {
        this.email = email;
        this.password = password;
    }
    public User(String email, Browser browser) {
        this.email = email;
        this.browser = browser;
        this.codes = new HashSet<>();
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getFailedTimes() {
        return failedTimes;
    }

    public Set<String> getCodes() {
        return codes;
    }
    public void setCodes(Set<String> codes) {
        this.codes = codes;
    }

    public Browser getBrowser() {
        return browser;
    }
    public void setBrowser(Browser browser) {
        this.browser = browser;
    }
    public void setFailedTimes(int failedTimes) {
        this.failedTimes = failedTimes;
    }

    public void loginFailed(){
        this.failedTimes+=1;
    }
    
    public void loginSuccess() {
        this.failedTimes = 0;
    }

    public boolean checkPassword(String password) {
        return Objects.equals(this.password,password);
    }

    public boolean checkCode(String code){
        return this.codes.contains(code);
    }

    public boolean isLocked(){
        return this.failedTimes>=3;
    }
}

