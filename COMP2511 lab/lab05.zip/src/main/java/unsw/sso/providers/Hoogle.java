package unsw.sso.providers;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import unsw.sso.Token;

public class Hoogle implements Checklock{
    private Map<String, User> userMappings = new HashMap<>();

    public void addUser(String email, String password) {
        userMappings.put(email, new User(email, password));
    }

    public Token generateFormSubmission(String email, String password) {
        User user = userMappings.get(email);
        if (user == null){
            return new Token(null, email, getClass().getSimpleName());
        }
        if (user.checkPassword(password) && !checkLock(email)) {
            user.loginSuccess();
            return new Token(UUID.randomUUID().toString(), email, getClass().getSimpleName());
        } else {
            user.loginFailed();
            return new Token(null, email, getClass().getSimpleName());
        }
    }

    @Override
    public boolean checkLock(String email){
        User user = userMappings.get(email);
        if (user == null) {
            return false;
        }
        return user.isLocked();
    }

}
