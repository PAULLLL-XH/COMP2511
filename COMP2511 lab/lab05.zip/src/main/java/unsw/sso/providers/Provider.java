package unsw.sso.providers;

import unsw.sso.Browser;

public interface Provider {
    public boolean checkLock(String email);
    
}
