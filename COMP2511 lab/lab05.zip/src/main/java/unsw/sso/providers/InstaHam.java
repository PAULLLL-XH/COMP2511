package unsw.sso.providers;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import unsw.sso.Browser;
import unsw.sso.Token;

public class InstaHam implements Checklock{
    private Map<String, User> users = new HashMap<>();

    public void addUser(String email, Browser browser) {
        users.put(email, new User(email,browser));
    }

    private Token getToken(String email, String code) {
        User user = users.get(email);
        if (user == null){
            // invalid!
            return new Token(null, email, getClass().getSimpleName());
        }
        if (user.checkCode(code) && !checkLock(email)){
            user.getCodes().remove(code);
            user.loginSuccess();
            return new Token(code, email, getClass().getSimpleName());
        }else{
            // invalid!
            user.loginFailed();
            return new Token(null, email, getClass().getSimpleName());
        }
    }

    public void broadcastCode(String email) {
        if (users.containsKey(email)) {
            Thread thread = new Thread(() -> {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                String code = UUID.randomUUID().toString();
                User user = users.get(email);
                user.getCodes().add(code);
                user.getBrowser().interact(getToken(email, code));
            });
            thread.start();
        }
    }

    public boolean checkLock(String email){
        User user = users.get(email);
        if (user == null) {
            return false;
        }
        return user.isLocked();
    }
}
