package unsw.sso.providers;

public interface Checklock {
    public boolean checkLock(String email);
    
}
