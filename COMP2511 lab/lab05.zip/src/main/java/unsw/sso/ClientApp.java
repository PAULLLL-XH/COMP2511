package unsw.sso;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import unsw.sso.providers.Checklock;
import unsw.sso.providers.InstaHam;

public class ClientApp {
    // HINT: Don't overcomplicate this
    //       for Task 2) you'll want some sort of object
    //       but don't go overboard, even in Task 4)
    //       this object can be relatively simple.
    private Map<String, Provider> providers = new HashMap<>();
    private final String name;

    public ClientApp(String name) {
        this.name = name;
    }

    public InstaHam getInstaHam() {
        Provider p = providers.getOrDefault("InstaHam",null);
        return p ==null ? null : p.getInstaHam();
    }

    public String getName() {
        return name;
    }

    // TODO: you'll probably want to change a lot of this class
    public void registerProvider(Checklock o) {
        String providerName = o.getClass().getSimpleName();
        this.providers.put(providerName, new Provider(o));
    }

    public boolean hasHoogle() {
        return this.providers.containsKey("Hoogle");
    }

    public boolean hasInstaHam() {
        return  providers.containsKey("InstaHam");
    }

    public boolean hasLinkedOut() {
        return  providers.containsKey("LinkedOut");
    }

    public void registerUser(Token token) {
        // only hoogle is supported right now!  So we presume hoogle on user
        Provider p = providers.getOrDefault(token.getProviderName(), null);
        p.put(token.getUserEmail(), true);
    }
    
    public boolean hasUserForProvider(String email, Checklock provider) {
        String name = provider.getClass().getSimpleName();
        Provider p = providers.getOrDefault(name, null);
        return p ==null ? false : p.getOrDefault(email, false);
    }

    public boolean hasUser(String email) {
        for (Entry<String, Provider> entry : providers.entrySet()) {
            if (entry.getValue().getOrDefault(email,false)){
                return true;
            }
        }
        return false;
    }
    
    public boolean checkLock(String email){
        for (Entry<String, Provider> entry : providers.entrySet()) {
            if (entry.getValue().checkLock(email)){
                entry.getValue().put(email, true);
                return true;
            }
        }
        return false;
    }
}
