package unsw.sso.pages;

import unsw.sso.ClientApp;
import unsw.sso.providers.Hoogle;
import unsw.sso.providers.InstaHam;
import unsw.sso.providers.LinkedOut;

public class SelectProvider extends Page{

    public SelectProvider() {
        super("Select a Provider");
    }

    @Override
    public Page interact(ClientApp app, Object using) {
        if (using instanceof Hoogle && app.hasHoogle()){
            return new HoogleLogin();
        }
        if (using instanceof InstaHam && app.hasInstaHam()){
            return new InstaHamLogin();
        }
        if (using instanceof LinkedOut && app.hasLinkedOut()) {
            return new LinkedOutLogin();
        }
        return new SelectProvider();
    }

    @Override
    public Page goBack() {
        // TODO Auto-generated method stub
        return new Null();
    }
    
}
