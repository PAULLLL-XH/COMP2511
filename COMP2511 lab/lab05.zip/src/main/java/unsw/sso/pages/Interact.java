package unsw.sso.pages;

import unsw.sso.ClientApp;

public interface Interact {
    public Interact interact(ClientApp app, Object using);
    public String getContent();
    public Interact goBack();
}
