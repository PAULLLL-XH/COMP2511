package unsw.sso.pages;

import unsw.sso.ClientApp;
import unsw.sso.Token;

public class InstaHamLogin extends Page{

    public InstaHamLogin() {
        super("InstaHam Login");
    }
    
    
    @Override
    public Page interact(ClientApp app, Object using) {
        if (!(using instanceof Token)){
            if (using instanceof String) {
                app.getInstaHam().broadcastCode((String)using);
            } else{
                return this.goBack();
            }
            return this;
        }
        Token t = (Token) using;
        if (app.checkLock(t.getUserEmail())){
            app.registerUser(t);
            return new UserLocked();
        }
        if (t.getAccessToken() == null){
            return this.goBack();
        }
        return new Home(this);
    }


    @Override
    public Page goBack() {
        return new SelectProvider();
    }

}
