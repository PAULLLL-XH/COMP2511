package unsw.sso.pages;

public abstract class Page implements Interact{
    private String content= null;

    public Page(String content) {
        this.content = content;
    }
    public String getContent() {
        return this.content;
    }
    public void setContent(String content) {
        this.content = content;
    }

}
