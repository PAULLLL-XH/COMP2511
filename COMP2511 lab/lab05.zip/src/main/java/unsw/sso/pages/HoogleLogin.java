package unsw.sso.pages;

import unsw.sso.ClientApp;
import unsw.sso.Token;

public class HoogleLogin extends Page{

    public HoogleLogin() {
        super("Hoogle Login");
    }
    
    
    @Override
    public Page interact(ClientApp app, Object using) {
        if (!(using instanceof Token)){
            return this.goBack();
        }
        Token t = (Token) using;
        if (app.checkLock(t.getUserEmail())){
            app.registerUser(t);
            return new UserLocked();
        }
        if (t.getAccessToken() == null){
            return this.goBack();
        }
        return new Home(this);
    }


    @Override
    public Page goBack() {
        return new SelectProvider();
    }

}
