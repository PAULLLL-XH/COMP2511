package unsw.sso.pages;

import unsw.sso.ClientApp;

public class Null extends Page{

    public Null() {
        super("null");
    }

    @Override
    public Page interact(ClientApp app, Object using) {
        return this; 
    }

    @Override
    public String getContent() {
        return null;
    }

    @Override
    public Page goBack() {
        return this;
    }
    
}

