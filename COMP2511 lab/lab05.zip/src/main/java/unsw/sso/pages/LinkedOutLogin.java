package unsw.sso.pages;

import unsw.sso.ClientApp;
import unsw.sso.Token;
import unsw.sso.providers.Hoogle;
import unsw.sso.providers.InstaHam;

public class LinkedOutLogin extends Page{

    public LinkedOutLogin() {
        super("LinkedOut Login");
    }

    @Override
    public Page interact(ClientApp app, Object using) {
        
        if (!(using instanceof Token)){
            return this.goBack();
        }
        Token t = (Token) using;

        if (app.checkLock(t.getUserEmail())){
            app.registerUser(t);
            return new UserLocked();
        }
        
        return new Home(this);
    }

    @Override
    public Page goBack() {
        return new Null();
    }

}
