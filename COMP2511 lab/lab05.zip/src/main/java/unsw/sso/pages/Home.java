package unsw.sso.pages;

import unsw.sso.ClientApp;
import unsw.sso.Token;

public class Home extends Page{
    private Interact previous = null;
    public Home(Interact previous) {
        super("Home");
        this.previous = previous;
    }

    @Override
    public Interact interact(ClientApp app, Object using) {
        if (using == null) {
            return new SelectProvider();
        }
        if (!(using instanceof Token)) {
            return this.goBack();
        }
        if (app.checkLock(((Token)using).getUserEmail())){
            return new UserLocked();
        }
        return this;        
    }

    @Override
    public Interact goBack() {
        return this.previous;
    }
}
