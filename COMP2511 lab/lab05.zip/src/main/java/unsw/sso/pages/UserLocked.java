/*
 * @Author: Xing Zhao
 * @Date: 2021-10-23 21:40:00
 * @Description: 
 */
package unsw.sso.pages;

import unsw.sso.ClientApp;

public class UserLocked extends Page {

    public UserLocked() {
        super("Locked");
    }
    
    @Override
    public Page interact(ClientApp app, Object using) {
        return this;
    }

    @Override
    public Page goBack() {
        return new SelectProvider();
    }
    
}
