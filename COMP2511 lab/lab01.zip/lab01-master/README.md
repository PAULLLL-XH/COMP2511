You can find the specification for this lab here:

https://unswcse.atlassian.net/wiki/spaces/cs2511/pages/27295745/Lab+01
