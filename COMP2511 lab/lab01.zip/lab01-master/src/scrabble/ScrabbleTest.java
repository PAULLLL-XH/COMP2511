package scrabble;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class ScrabbleTest {
    /*@Test
    public void testDocumentation1() {
        Scrabble s1 = new Scrabble("lion");
        assertEquals(7, s1.score());
    }

    @Test
    public void testDocumentation2() {
        Scrabble s2 = new Scrabble("bread");
        assertEquals(18, s2.score());
    }

    @Test
    public void testNoOtherSubwords() {
        Scrabble s = new Scrabble("te");
        assertEquals(1, s.score());
    }

    @Test
    public void testNotAWord() {
        Scrabble s = new Scrabble("oiwede");
        assertEquals(0, s.score());
    }

    @Test
    public void testScrabble() {
        Scrabble s = new Scrabble("scrabble");
        assertEquals(11, s.score());
    }*/
}