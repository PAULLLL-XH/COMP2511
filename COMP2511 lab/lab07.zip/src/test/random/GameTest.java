package random;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class GameTest {
    
    @Test
    public void testSeed4() {
        boolean[] expected = {true, true, false, true, true, false, false, false, true, false};
        Game game = new Game(4);
        for (int i = 0; i < 10; i++) {
            assertEquals(expected[i], game.battle());
        }
    }

    @Test
    public void testSeed0() {
        boolean[] expected = {true, false, false, false, false, true, true, true, false, true};
        Game game = new Game(0);
        for (int i = 0; i < 10; i++) {
            assertEquals(expected[i], game.battle());
        }
    }

}