package bool;

import org.json.JSONObject;

public class NodeFactory {
    
    private JSONObject node;
    private BooleanNode booleanNode;

    public NodeFactory(JSONObject node) {
        this.node = node;
        this.booleanNode = generateBooleanNode();
    }

    public String prettyPrint() {
        return this.booleanNode.getString();
    }

    public boolean evaluate() {
        return this.booleanNode.getValue();
    }

    public BooleanNode generateBooleanNode() {
        return generateBooleanNodeHelper(this.node);
    }

    private BooleanNode generateBooleanNodeHelper(JSONObject node) {
        String operation = node.getString("node");
        if (operation.equalsIgnoreCase("and") || operation.equalsIgnoreCase("or")) {
            BooleanNode left = generateBooleanNodeHelper(node.getJSONObject("subnode1"));
            BooleanNode right = generateBooleanNodeHelper(node.getJSONObject("subnode2"));
            return getBooleanNode(operation, left, right);
        }
        else if (operation.equalsIgnoreCase("not")) {
            BooleanNode left = generateBooleanNodeHelper(node.getJSONObject("subnode1"));
            return getBooleanNode(operation, left);
        }
        else if (operation.equalsIgnoreCase("value")){
            return getBooleanNode(node.getBoolean("value"));
        }
        return null;
    }

    private BooleanNode getBooleanNode(String node, BooleanNode right, BooleanNode left) {
        if (node.equalsIgnoreCase("and")) {
            return new BooleanAndOperator(left, right);
        }
        if (node.equalsIgnoreCase("or")) {
            return new BooleanOrOperator(left, right);
        }
        return null;
    }

    private BooleanNode getBooleanNode(String node, BooleanNode booleanNode) {
        if (node.equalsIgnoreCase("not")) {
            return new BooleanNotOperator(booleanNode);
        }
        return null;
    }

    private BooleanNode getBooleanNode(boolean statement) {
        return new BooleanLeafNode(statement);
    }

    public static void main(String[] args) {
        JSONObject json = new JSONObject();
        json.put("node", "and");
        JSONObject subnode1 = new JSONObject();
        subnode1.put("node", "or");
        JSONObject subnode11 = new JSONObject();
        subnode11.put("node", "value");
        subnode11.put("value", true);
        JSONObject subnode12 = new JSONObject();
        subnode12.put("node", "value");
        subnode12.put("value", false);
        subnode1.put("subnode1", subnode11);
        subnode1.put("subnode2", subnode12);

        JSONObject subnode2 = new JSONObject();
        subnode2.put("node", "value");
        subnode2.put("value", true);

        json.put("subnode1", subnode1);
        json.put("subnode2", subnode2);

        System.out.println(json);
        NodeFactory fac = new NodeFactory(json);
        System.out.println(fac.prettyPrint());
        System.out.println(fac.evaluate());
    }
}