/*
 * @Author: Echooooo-zhn haonanZHONG17@outlook.com
 * @Date: 2022-07-12 19:16:47
 * @LastEditors: Echooooo-zhn haonanZHONG17@outlook.com
 * @LastEditTime: 2022-07-12 19:16:52
 * @FilePath: \week7\lab07-master\src\main\bool\BooleanNotOperator.java
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package bool;

public class BooleanNotOperator extends BooleanOperator{

    public BooleanNotOperator(BooleanNode node) {
        super(node);
    }

    @Override
    public boolean applyOperation(boolean left, boolean right) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean applyOperation(boolean node) {
        // TODO Auto-generated method stub
        return (!node);
    }

    @Override
    public String combineOperation(String left, String right) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String combineOperation(String node) {
        // TODO Auto-generated method stub
        String s = "(" + "NOT " + node + ")";
        return s;
    }
    
}
