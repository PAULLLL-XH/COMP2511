package bool;

public class BooleanEvaluator {

    public static boolean evaluate(BooleanNode expression) {
        // Return the expression evaluated
        return expression.getValue();
    }

    public static String prettyPrint(BooleanNode expression) {
        // Pretty print the expression
        return expression.getString();
    }

    public static void main(String[] args) {
        // BooleanEvaluator.evaluate(...)
        // BooleanEvaluator.evaluate(...)

        BooleanNode expression1 = new BooleanAndOperator(new BooleanLeafNode(true), new BooleanLeafNode(false));
        String statement1 = BooleanEvaluator.prettyPrint(expression1);
        boolean s1 = BooleanEvaluator.evaluate(expression1);
        System.out.println("Pretty print: " + statement1);
        System.out.println("Result " + s1);


        BooleanNode expression3 = new BooleanOrOperator(new BooleanLeafNode(true), new BooleanNotOperator(new BooleanAndOperator(new BooleanLeafNode(false), new BooleanOrOperator(new BooleanLeafNode(true), new BooleanLeafNode(false)))));
        String statement3 = BooleanEvaluator.prettyPrint(expression3);
        boolean s3 = BooleanEvaluator.evaluate(expression3);
        System.out.println("Pretty print: " + statement3);
        System.out.println("Result " + s3);

    }

}