
package bool;

public abstract class BooleanOperator implements BooleanNode {

    private BooleanNode left;
    private BooleanNode right;

    public BooleanOperator(BooleanNode left, BooleanNode right) {
        this.left = left;
        this.right = right;
    }

    public BooleanOperator(BooleanNode node) {
        this.left = node;
    }
    
    @Override
    public boolean getValue() {
        if (right == null) {
            return applyOperation(left.getValue());
        }
        return applyOperation(left.getValue(), right.getValue());
    }

    @Override
    public String getString() {
        if (right == null) {
            return combineOperation(left.getString());
        }
        return combineOperation(left.getString(), right.getString());
    }

    public abstract boolean applyOperation(boolean left, boolean right);
    public abstract boolean applyOperation(boolean node);
    public abstract String combineOperation(String left, String right);
    public abstract String combineOperation(String node);
}
