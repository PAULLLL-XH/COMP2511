package bool;

public class BooleanLeafNode implements BooleanNode{

    private boolean statement;

    public BooleanLeafNode(boolean statement) {
        this.statement = statement;
    }

    @Override
    public boolean getValue() {
        // TODO Auto-generated method stub
        return statement;
    }

    @Override
    public String getString() {
        // TODO Auto-generated method stub
        if (statement) {
            return "true";
        }
        return "false";
    }
    
}
