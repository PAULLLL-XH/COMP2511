package bool;

public class BooleanOrOperator extends BooleanOperator {

    public BooleanOrOperator(BooleanNode left, BooleanNode right) {
        super(left, right);
    }
    
    @Override
    public boolean applyOperation(boolean left, boolean right) {
        return (left || right);
    }

    @Override
    public String combineOperation(String left, String right) {
        String statement = "(" + "OR " + left + " " + right + ")";
        return statement; 
    }

    @Override
    public boolean applyOperation(boolean node) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public String combineOperation(String node) {
        // TODO Auto-generated method stub
        return null;
    }
}
