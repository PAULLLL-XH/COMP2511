package bool;

public class BooleanAndOperator extends BooleanOperator {

    public BooleanAndOperator(BooleanNode left, BooleanNode right) {
        super(left, right);
    }
    
    @Override
    public boolean applyOperation(boolean left, boolean right) {
        // TODO Auto-generated method stub
        return (left && right);
    }

    @Override
    public boolean applyOperation(boolean node) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public String combineOperation(String left, String right) {
        // TODO Auto-generated method stub
        String statement = "(" + "AND" + " " + left + " " + right + ")";
        return statement;
    }

    @Override
    public String combineOperation(String node) {
        // TODO Auto-generated method stub
        return null;
    }
    
    
}
