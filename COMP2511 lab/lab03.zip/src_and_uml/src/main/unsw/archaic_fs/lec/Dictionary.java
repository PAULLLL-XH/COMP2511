package unsw.archaic_fs.lec;

public interface Dictionary<K, V> {
    public K getKey();
    public V getValue();

}