package unsw.archaic_fs.lec;

import jdk.jshell.execution.Util;

public class ShopDictionary<K, V> implements Dictionary<K, V>{
    private K key;
    private V value;

    public ShopDictionary(K key, V value) {
        this.key = key;
        this.value = value;
    }

    @Override
    public K getKey() {
        return this.key;
    }

    @Override
    public V getValue() {
        return this.value;
    }

    public static void main(String args[]) {
        ShopDictionary<String, Integer> guide1 = new ShopDictionary<String,Integer>("apple", 1);
        ShopDictionary<String, Integer> guide2 = new ShopDictionary<String,Integer>("banana", 2);
        
        ShopDictionary<Integer, String> guide3 = new ShopDictionary<Integer, String>(3, "pear");

        int valueInt = guide1.getValue();
        System.out.println(valueInt);

        String valueString = guide3.getValue();
        System.out.println(valueString);

        int keyInt = guide3.getKey();
        System.out.println(keyInt);

        String keyString = guide1.getKey();
        System.out.println(keyString);
    }
}
