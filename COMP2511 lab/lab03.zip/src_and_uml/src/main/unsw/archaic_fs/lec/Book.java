/*
 * @Author: your name
 * @Date: 2021-09-28 23:57:43
 * @LastEditTime: 2022-06-14 00:53:10
 * @LastEditors: Echooooo-zhn haonanZHONG17@outlook.com
 * @Description: In User Settings Edit
 * @FilePath: \lab03\src\lec\Book.java
 */
package unsw.archaic_fs.lec;

public class Book<T> {
    
    private T t;

    public void set(T t) {
        this.t = t;
    }

    public T get() {
        return this.t;
    }

    public static void main(String args[]) {
        Book<Integer> intBook = new Book<>();
        // Book<Integer> intBook = new Book<Integer>();
        intBook.set(5);
    
        Book<String> stringBook = new Book<>();
        stringBook.set("5");

        System.out.println(intBook.getClass());
        System.out.println(stringBook.getClass());
    }
}
