/*
 * @Author: Echooooo-zhn haonanZHONG17@outlook.com
 * @Date: 2021-09-29 03:34:50
 * @LastEditors: Echooooo-zhn haonanZHONG17@outlook.com
 * @LastEditTime: 2022-06-13 23:59:28
 * @FilePath: \lab03\src\lec\LeastKnowledgeDemo.java
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
// package lec;

// public class LeastKnowledgeDemo {
    
//     // 1. 一个对象中的方法可以调用该对象中本身的任何方法
//     public class ObjectA {
        
//         public void methodA() {
//             this.methodB();
//         }

//         public void methodB() {

//         }
//     }

//     // 2. 一个对象中的方法可以调用传递给该方法的参数所带的任何方法
//     public class ObjectB() {
//         public void methodOfB(ObjectBsFriend friend) {
//             friend.methodOfBFriend();
//         }
//     }

//     public class ObjectBsFriend() {
//         public void methodOfBFriend() {
            
//         }
//     }


//     // 3. 如何一个对象在一个方法中被实例化了，则这个方法可以调用这个实例化对象
//     public class ObjectB() {

//         public void methodOfB() {
            
//             ObjectBsFriend friend = new ObjectBsFriend();
//             friend.methodOfBFriend();
//         }
//     }

//     public class ObjectBsFriend() {
//         public void methodOfBFriend() {
            
//         }
//     }

//     // 4. 一个对象中的方法可以调用该对象的直接组成部分有的方法或对象
//     public class ObjectB() {

//         public ObjectBsFriend friend = new ObjectBsFriend();

//         public void methodOfB() {
//             friend.methodOfBFriend();
//         }
//     }

//     public class ObjectBsFriend() {
//         public void methodOfBFriend() {
            
//         }
//     }
// }
