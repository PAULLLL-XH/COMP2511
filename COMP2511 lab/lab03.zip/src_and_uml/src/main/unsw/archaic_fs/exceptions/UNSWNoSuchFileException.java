package unsw.archaic_fs.exceptions;

import java.io.FileNotFoundException;

public class UNSWNoSuchFileException extends FileNotFoundException{
    public UNSWNoSuchFileException(String message) {
        super(message);
    }
}