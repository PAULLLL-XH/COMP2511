package unsw.graph;

import java.util.*;


public class DepthFirstGraphIterator<N extends Comparable<N>> implements Iterator<N> {
    private N node;
    private Graph<N> graph;
    private List<N> stack;
    private Set<N> visited;

    public DepthFirstGraphIterator(N node, Graph<N> graph) {
        this.node = node;
        this.graph = graph;
        this.stack = new ArrayList<N>();
        this.stack.add(node);
        this.visited = new HashSet<N>();
        this.visited.add(node);
    }


    @Override
    public boolean hasNext() {
        if (!stack.isEmpty()) {
            return true;
        }
        return false;
    }

    @Override
    public N next() {
        if (hasNext()) {
            N pop = stack.get(0);
            List<N> newS = new ArrayList<N>();
            for (N n: graph.getAdjacentNodes(pop)) {
                if (!visited.contains(n)) {
                    newS.add(n);
                    visited.add(n);
                }
            }
            stack.remove(0);
            newS.addAll(stack);
            this.setStack(newS);
            return pop;
        }
        return null;
    } 

    private void setStack(List<N> s) {
        this.stack = s;
    }
}

