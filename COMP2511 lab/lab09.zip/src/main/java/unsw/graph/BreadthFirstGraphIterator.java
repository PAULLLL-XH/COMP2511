package unsw.graph;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.Queue;
import java.util.Set;

public class BreadthFirstGraphIterator<N extends Comparable<N>> implements Iterator<N> {
    
    private N node;
    private Graph<N> graph;
    private Queue<N> queue;
    private Set<N> visited;

    public BreadthFirstGraphIterator(N node, Graph<N> graph) {
        this.node = node;
        this.graph = graph;
        this.queue = new LinkedList<N>();
        this.queue.add(node);
        this.visited = new HashSet<N>();
        this.visited.add(node);
    }


    @Override
    public boolean hasNext() {
        if (!queue.isEmpty()) {
            return true;
        }
        return false;
    }

    @Override
    public N next() {
        if (hasNext()) {
            N pop = queue.poll();
            for (N n: graph.getAdjacentNodes(pop)) {
                if (!visited.contains(n)) {
                    queue.add(n);
                    visited.add(n);
                }
            }
            return pop;
        }
        return null;
    } 
}

