package unsw.cycle;

import java.util.Iterator;

public class CycleIterator<E> implements Iterator<E> {

    @Override
    public boolean hasNext() {
        // TODO = implement this
        return false;
    }

    @Override
    public E next() {
        // TODO = implement this
        return null;
    }
 
}
