package unsw.hamper;

public abstract class ToyCar extends Item {
}
