package unsw.calculator.view;

public class EvaluatorAdapter {

}