package unsw.calculator.model;

import unsw.calculator.model.tree.BinaryOperatorNode;
import unsw.calculator.model.tree.NumericNode;

public class PostFixPrintVisitor implements Visitor{
    
    @Override
    public void visitBinaryOperatorNode(BinaryOperatorNode node) {
        if (node.getLeft() != null) {
            if (node.getLeft() instanceof BinaryOperatorNode) {
                visitBinaryOperatorNode((BinaryOperatorNode) node.getLeft());
            }
            else if (node.getLeft() instanceof NumericNode) {
                visitNumericNode((NumericNode) node.getLeft());
            }
        }
        System.out.print(" ");
        if (node.getRight() != null) {
            if (node.getRight() instanceof BinaryOperatorNode) {
                visitBinaryOperatorNode((BinaryOperatorNode)node.getRight());
            }
            else if (node.getRight() instanceof NumericNode){
                visitNumericNode((NumericNode)node.getRight());
            }
        }
        System.out.print(" " + node.getLabel());
    }

    @Override
    public void visitNumericNode(NumericNode node) {
        System.out.print(node.getLabel()); 
    }
}