package unsw.calculator.model;


import javax.swing.tree.TreeNode;
import unsw.calculator.model.tree.BinaryOperatorNode;
import unsw.calculator.model.tree.NumericNode;

public class EvaluatorVisitor implements Visitor{ 
    private int result;

    @Override
    public void visitBinaryOperatorNode(BinaryOperatorNode node) {
        this.result = getValueHelp(node);
    }

    @Override
    public void visitNumericNode(NumericNode node) {
        this.result = node.getValue();
    }

    public int getValue() {
        return this.result;
    }

    private int getValueHelp(BinaryOperatorNode node) {
        int left = 0;
        int right = 0;
        if (node.getLeft() != null) {
            if (node.getLeft() instanceof BinaryOperatorNode) {
                left = getValueHelp((BinaryOperatorNode) node.getLeft());
            }
            else if (node.getLeft() instanceof NumericNode) {
                NumericNode temp = (NumericNode) node.getLeft();
                left = temp.getValue();
            }
        }
        if (node.getRight() != null) {
            if (node.getRight() instanceof BinaryOperatorNode) {
                right = getValueHelp((BinaryOperatorNode)node.getRight());
            }
            else if (node.getRight() instanceof NumericNode){
                NumericNode temp = (NumericNode)node.getRight();
                right = temp.getValue();
            }
        }
        return node.compute(left, right);
    }
}