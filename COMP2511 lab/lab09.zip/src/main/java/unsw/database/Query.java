package unsw.database;

public class Query {
    // you are to implement this function.
}
